# -*- coding: utf-8 -*-
"""
Seriesly - Ελληνική TV από τα επίσημα sites των καναλιών.

Διαβάζει τον κατάλογο από το API του καταλόγου (WordPress) και παίζει
τα βίντεο απευθείας από τους servers των καναλιών. Δεν κάνει scraping το ίδιο.
"""
import os
import re
import sys
import json
import unicodedata
from datetime import datetime
from urllib.parse import urlencode, parse_qsl
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon()
VERSION = ADDON.getAddonInfo('version')
ICON = ADDON.getAddonInfo('icon')
FANART = ADDON.getAddonInfo('fanart')
MEDIA = os.path.join(ADDON.getAddonInfo('path'), 'resources', 'media')


def media(name):
    """Εικονίδιο στο θέμα που διάλεξε ο χρήστης (resources/media/ΘΕΜΑ/ΟΝΟΜΑ.png)· ίδια σχήματα σε όλα τα θέματα."""
    path = os.path.join(MEDIA, opt('icon_theme'), name + '.png')
    return path if os.path.exists(path) else os.path.join(MEDIA, 'seriesly', name + '.png')
DEFAULT_API = 'https://e-menucms.gr/wp-json/seriesly/v1'
# Η παλιά διεύθυνση του καταλόγου (πριν τη μετονομασία) — μόνο για κατάλογο που δεν έχει ακόμα ενημερωθεί. Δεν γράφεται αυτούσια στον κώδικα.
LEGACY_NS = ''.join(chr(c) for c in (100, 112, 56, 50, 116, 117, 98, 101))

BASE_URL = sys.argv[0]
HANDLE = int(sys.argv[1])
ARGS = dict(parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}


# ---------------------------------------------------------------- βοηθητικά

# ---------------------------------------------------------------- ρυθμίσεις (ένα πάτημα)

# Προβολές του Estuary (το προεπιλεγμένο skin του Kodi): Λίστα 50 (προεπιλογή) · Ευρεία Λίστα 55 · Αφίσες 51 · Τοίχος 500.
VIEWS = [('50', 'Λίστα'), ('55', 'Ευρεία Λίστα'), ('51', 'Αφίσες'), ('500', 'Τοίχος'), ('auto', 'Αυτόματη')]
# κλειδί: (τίτλος, [(τιμή, ετικέτα)…]) — η πρώτη τιμή είναι η προεπιλογή.
OPTIONS = {
    'show_channel':  ('Κανάλι Δίπλα Στον Τίτλο', [('true', 'Ναι'), ('false', 'Όχι')]),
    'color_channel': ('Χρώμα Καναλιού', [('true', 'Ναι'), ('false', 'Όχι')]),
    'show_sort':     ('Ταξινόμηση Εκπομπών', [('alpha', 'Αλφαβητικά'), ('recent', 'Πιο Πρόσφατες Πρώτα')]),
    'show_counts':   ('Πλήθος Δίπλα Στις Κατηγορίες', [('true', 'Ναι'), ('false', 'Όχι')]),
    'per_page':      ('Επεισόδια Ανά Σελίδα', [('50', '50'), ('25', '25'), ('100', '100')]),
    'icon_theme':    ('Θέμα Εικονιδίων', [('seriesly', 'Seriesly'), ('color', 'Πολύχρωμο'), ('mono', 'Σκούρο'),
                                          ('light', 'Φωτεινό')]),
    'view_menus':    ('Προβολή Μενού', VIEWS),
    'view_shows':    ('Προβολή Εκπομπών', VIEWS),
    'view_episodes': ('Προβολή Επεισοδίων', VIEWS),
    'kids_mode':     ('Λειτουργία Παιδιών', [('false', 'Όχι'), ('true', 'Ναι')]),
    'streams_on':    ('Συνεχής Ροή', [('true', 'Εμφανίζεται'), ('false', 'Κρυφή')]),
}
KEY_ICONS = {'icon_theme': 'theme', 'view_': 'view', 'kids_mode': 'kidslock', 'streams_on': 'stream'}
APPEARANCE = ('icon_theme', 'view_menus', 'view_shows', 'view_episodes', 'show_channel', 'color_channel',
              'show_sort', 'show_counts')
FUNCTIONS = ('per_page', 'kids_mode')
CONTENT = ('streams_on',)
CHANNEL_COLORS = {'mega': 'FFE8453C', 'alpha': 'FF4FA3F7', 'skai': 'FF2F80ED', 'open': 'FFF2994A', 'star': 'FFF2C94C',
                  'ant1': 'FFEB5757', 'ert': 'FF27AE60'}


def opt(key):
    """Τρέχουσα τιμή ρύθμισης (αν δεν έχει οριστεί ή είναι άκυρη: η προεπιλογή)."""
    values = [v for v, _ in OPTIONS[key][1]]
    value = ADDON.getSetting(key)
    return value if value in values else values[0]


def opt_label(key):
    return dict(OPTIONS[key][1])[opt(key)]


def channel_tag(item):
    """«  [MEGA]» δίπλα στον τίτλο — με χρώμα ανά κανάλι, αν είναι ενεργό."""
    if opt('show_channel') != 'true':
        return ''
    name = item.get('channel_label', '')
    color = CHANNEL_COLORS.get(item.get('channel', ''), '')
    if color and opt('color_channel') == 'true':
        return '  [COLOR %s][%s][/COLOR]' % (color, name)
    return '  [%s]' % name


# ---------------------------------------------------------------- αγαπημένα (αρχείο στο προφίλ του πρόσθετου)

def fav_file():
    folder = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    if not xbmcvfs.exists(folder):
        xbmcvfs.mkdirs(folder)
    return os.path.join(folder, 'favourites.json')


FAV_SETTING = 'favs_json'


def fav_load():
    """Τα αγαπημένα ζουν στις ρυθμίσεις του πρόσθετου (το Kodi τις γράφει πάντα). Τα παλιά, από αρχείο, μεταφέρονται μία φορά."""
    raw = ADDON.getSetting(FAV_SETTING)
    if raw:
        try:
            data = json.loads(raw)
            return data if isinstance(data, list) else []
        except ValueError:
            log('χαλασμένα αγαπημένα στις ρυθμίσεις — αγνοούνται', xbmc.LOGWARNING)
    try:
        with open(fav_file(), 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        if isinstance(data, list) and data:
            ADDON.setSetting(FAV_SETTING, json.dumps(data, ensure_ascii=False))
            return data
    except (OSError, ValueError):
        pass
    return []


def fav_save(items):
    """Αποθηκεύει και ΕΠΑΛΗΘΕΥΕΙ ότι γράφτηκε. Επιστρέφει True/False."""
    text = json.dumps(items, ensure_ascii=False)
    try:
        ADDON.setSetting(FAV_SETTING, text)
        return ADDON.getSetting(FAV_SETTING) == text
    except Exception as exc:
        log('δεν αποθηκεύτηκαν τα αγαπημένα: %s' % exc, xbmc.LOGWARNING)
        return False


def fav_key(channel, show_id):
    return '%s:%s' % (channel, show_id)


def fav_keys():
    return set(fav_key(x.get('channel'), x.get('id')) for x in fav_load())


def fav_menu(channel, show_id, title, image='', poster=''):
    """Μενού (παρατεταμένο πάτημα / δεξί κλικ): προσθήκη ή αφαίρεση από τα Αγαπημένα."""
    if fav_key(channel, show_id) in fav_keys():
        return [('★ Αφαίρεση Από Τα Αγαπημένα',
                 'RunPlugin(%s)' % build_url(mode='fav_del', channel=channel, show=show_id))]
    return [('☆ Προσθήκη Στα Αγαπημένα',
             'RunPlugin(%s)' % build_url(mode='fav_add', channel=channel, show=show_id, title=title,
                                         image=image, poster=poster))]


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[Seriesly %s] %s' % (VERSION, msg), level)


def api_base():
    url = (ADDON.getSetting('api_url') or '').strip().rstrip('/')
    return url or DEFAULT_API


def migrate_api():
    """1.10.0: αν η αποθηκευμένη διεύθυνση API είναι η παλιά, γίνεται η νέα (μία φορά)· οι προσαρμοσμένες διευθύνσεις δεν πειράζονται."""
    url = (ADDON.getSetting('api_url') or '').strip()
    if url and ('/%s/' % LEGACY_NS) in url + '/':
        ADDON.setSetting('api_url', url.replace('/%s/' % LEGACY_NS, '/seriesly/').replace('/%s' % LEGACY_NS, '/seriesly'))


def per_page():
    return int(opt('per_page'))



def hidden_list(key):
    """Κρυμμένα κανάλια (hide_channels) ή τύποι (hide_types): αποθηκεύεται η ΕΞΑΙΡΕΣΗ — κενό = όλα ορατά."""
    return [x for x in (ADDON.getSetting(key) or '').split(',') if x]


def channel_hidden(channel_id):
    return bool(channel_id) and channel_id in hidden_list('hide_channels')


def type_hidden(type_id):
    return bool(type_id) and type_id in hidden_list('hide_types')


def fav_visible():
    """Τα αγαπημένα χωρίς όσα ανήκουν σε κρυμμένο κανάλι."""
    return [x for x in fav_load() if not channel_hidden(x.get('channel'))]


def api(path, **params):
    """GET στο API του καταλόγου. Επιστρέφει dict ή None (με ειδοποίηση).
    Στις λίστες (/menu, /shows, /latest) προστίθενται οι εξαιρέσεις xc/xt (κρυμμένα κανάλια/τύποι)· με _raw=1 όχι (π.χ. στις Ρυθμίσεις)."""
    raw = params.pop('_raw', False)
    quiet = params.pop('_quiet', False)   # 1.14.0: έλεγχοι που δεν πρέπει να ενοχλούν με ειδοποίηση αν ο κατάλογος δεν απαντά
    if not raw and path in ('/menu', '/shows', '/latest'):
        xc = ','.join(hidden_list('hide_channels'))
        xt = ','.join(hidden_list('hide_types'))
        if xc:
            params['xc'] = xc
        if xt:
            params['xt'] = xt
    params = dict((k, v) for k, v in params.items() if v not in (None, ''))
    url = api_base() + path + ('?' + urlencode(params) if params else '')
    urls = [url]
    if '/seriesly/' in url:
        urls.append(url.replace('/seriesly/', '/%s/' % LEGACY_NS, 1))   # κατάλογος που δεν έχει ακόμα ενημερωθεί: δοκιμάζεται η παλιά διεύθυνση
    last = None
    for attempt in urls:
        req = Request(attempt, headers={
            'User-Agent': 'Seriesly-Kodi/' + VERSION,
            'Accept': 'application/json',
        })
        try:
            with urlopen(req, timeout=20) as res:
                return json.loads(res.read().decode('utf-8'))
        except HTTPError as e:
            last = e
            if e.code != 404:   # μόνο το 404 σημαίνει «αυτή η διεύθυνση δεν υπάρχει» — τα άλλα σφάλματα δεν δοκιμάζονται ξανά
                break
        except (URLError, ValueError, OSError) as e:
            last = e
            break
    log('%s -> %s' % (url, last), xbmc.LOGERROR)
    if not quiet:
        xbmcgui.Dialog().notification('Seriesly', 'Ο κατάλογος δεν απαντά', ICON, 5000)
    return None


def build_url(**query):
    return BASE_URL + '?' + urlencode(dict((k, v) for k, v in query.items() if v not in (None, '')))


def local_date(iso):
    """'2026-09-23T18:20:00+00:00' -> ('23/09/2026', '2026-09-23') σε τοπική ώρα."""
    if not iso:
        return '', ''
    try:
        dt = datetime.fromisoformat(iso).astimezone()
    except ValueError:
        return '', ''
    return dt.strftime('%d/%m/%Y'), dt.strftime('%Y-%m-%d')


def set_info(li, title='', plot='', mediatype='video', aired='', show='', genres=None, studio='', duration=0):
    """InfoTagVideo (Kodi 20+), με εφεδρικό setInfo για παλαιότερα."""
    try:
        tag = li.getVideoInfoTag()
        tag.setMediaType(mediatype)
        if title:
            tag.setTitle(title)
        if plot:
            tag.setPlot(plot)
        if aired:
            tag.setFirstAired(aired)
            tag.setPremiered(aired)
        if show:
            tag.setTvShowTitle(show)
        if genres:
            tag.setGenres(genres)
        if studio:
            tag.setStudios([studio])
        if duration:
            tag.setDuration(int(duration))
    except AttributeError:
        info = {'title': title, 'plot': plot, 'mediatype': mediatype}
        if aired:
            info['aired'] = aired
        if show:
            info['tvshowtitle'] = show
        if genres:
            info['genre'] = genres
        if studio:
            info['studio'] = studio
        if duration:
            info['duration'] = int(duration)
        li.setInfo('video', info)


def art(thumb='', poster='', fanart=''):
    return {
        'icon': thumb or poster or ICON,
        'thumb': thumb or poster or ICON,
        'poster': poster or thumb or ICON,
        'fanart': fanart or FANART,
    }


def add_folder(label, query, thumb='', poster='', plot='', icon='', menu=None):
    li = xbmcgui.ListItem(label)
    if menu:
        li.addContextMenuItems(menu)
    li.setArt(art(thumb, poster))
    if icon:
        li.setArt({'icon': media(icon), 'thumb': media(icon)})
    if plot:
        set_info(li, title=label, plot=plot)
    xbmcplugin.addDirectoryItem(HANDLE, build_url(**query), li, isFolder=True)


def add_playable(label, stream, thumb='', poster='', plot='', aired='', show='', genres=None, studio='', duration=0,
                 menu=None):
    li = xbmcgui.ListItem(label)
    if menu:
        li.addContextMenuItems(menu)
    li.setArt(art(thumb, poster))
    li.setProperty('IsPlayable', 'true')
    set_info(li, title=label, plot=plot, mediatype='episode', aired=aired, show=show, genres=genres, studio=studio,
             duration=duration)
    xbmcplugin.addDirectoryItem(HANDLE, build_url(mode='play', url=stream), li, isFolder=False)


def add_next_page(data, query):
    page = int(data.get('page', 1))
    pages = int(data.get('pages', 1))
    if page < pages:
        nxt = dict(query)
        nxt['page'] = page + 1
        add_folder('Επόμενη Σελίδα (%d/%d) ›' % (page + 1, pages), nxt, icon='next')


def end(content=None, cache=True):
    key = {'tvshows': 'view_shows', 'episodes': 'view_episodes'}.get(content, 'view_menus')
    view = opt(key)
    if not content and view != 'auto':
        content = 'videos'   # το Estuary δείχνει «Αφίσες»/«Τοίχο» μόνο σε οθόνες με περιεχόμενο βίντεο
    if content:
        xbmcplugin.setContent(HANDLE, content)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=cache)
    if view != 'auto':
        xbmc.executebuiltin('Container.SetViewMode(%s)' % view)


def duration_of(item):
    """Διάρκεια σε δευτερόλεπτα από το API (0 = άγνωστη)."""
    try:
        return max(0, int(item.get('duration') or 0))
    except (TypeError, ValueError):
        return 0


def genre_labels(genres):
    return [g.get('label', '') for g in (genres or []) if g.get('label')]


# ---------------------------------------------------------------- οθόνες

# Τύποι όπως στο Seriesly, με την ίδια σειρά (τα Ντοκιμαντέρ μετά τις Εκπομπές· τα Παιδικά πριν από τα Αθλητικά).
TYPES = (('series', 'Σειρές'), ('show', 'Εκπομπές'), ('docs', 'Ντοκιμαντέρ'), ('kids', 'Παιδικά'), ('sports', 'Αθλητικά'))
TYPE_NAMES = dict(TYPES)
TYPE_ICONS = {'series': 'series', 'show': 'shows', 'docs': 'genres', 'kids': 'kids', 'sports': 'sports'}
# Κατηγορίες που ΔΕΝ εμφανίζονται στο αρχικό μενού όσο ο κατάλογος δεν έχει καμία εκπομπή του τύπου (εμφανίζονται μόνες τους μόλις υπάρξει υλικό).
HIDE_EMPTY = ('docs',)
# Κατηγορίες που στο μενού τους δείχνουν «πρόσφατα» ΜΟΝΟ όταν υπάρχει κάτι να δεις (1.14.0): χωρίς πρόσφατα δεν υπάρχουν τα υπομενού Προστέθηκαν Πρόσφατα / Σήμερα / Χθες / Τελευταία Εβδομάδα.
HIDE_NO_RECENT = ('docs',)


def kids_on():
    return opt('kids_mode') == 'true'


def root():
    if kids_on():
        kids_root()
        return
    counts = {}
    data = api('/menu')
    if data:
        for item in data.get('types', []):
            counts[item.get('id')] = int(item.get('shows', 0))
    mine = fav_visible()
    if mine:   # «Αγαπημένα Μου»: ΠΡΩΤΗ επιλογή και ΜΟΝΟ όταν υπάρχουν αγαπημένα (εκτός κρυμμένων καναλιών)· χωρίς αγαπημένα δεν εμφανίζεται τίποτα
        add_folder('★ Αγαπημένα Μου' + ('  (%d)' % len(mine) if opt('show_counts') == 'true' else ''), {'mode': 'favs'}, icon='favourites',
                   plot='Οι σειρές και οι εκπομπές που έβαλες στα αγαπημένα — και τα νέα επεισόδιά τους')
    for tid, label in TYPES:
        if type_hidden(tid):
            continue
        if tid in HIDE_EMPTY and data and counts.get(tid, 0) == 0:
            continue   # άδεια κατηγορία: δεν φαίνεται (αν ο κατάλογος δεν απάντησε, δεν κρύβεται τίποτα)
        shown = '%s  (%d)' % (label, counts[tid]) if (tid in counts and opt('show_counts') == 'true') else label
        add_folder(shown, {'mode': 'type', 'type': tid}, icon=TYPE_ICONS[tid])
    li = xbmcgui.ListItem('Σημερινό Πρόγραμμα')
    li.setArt({'icon': media('schedule'), 'thumb': media('schedule'), 'fanart': FANART})
    set_info(li, title='Σημερινό Πρόγραμμα', plot='Το τηλεοπτικό πρόγραμμα της ημέρας ανά κανάλι · ▶ = υπάρχει στο Seriesly')
    xbmcplugin.addDirectoryItem(HANDLE, build_url(mode='schedule'), li, isFolder=False)
    if opt('streams_on') != 'false':
        add_folder('Συνεχής Ροή', {'mode': 'streams'}, icon='stream',
                   plot='«Κανάλια» που παίζουν συνεχόμενα επεισόδια — πατάς ένα και απλώς βλέπεις')
    add_folder('Αναζήτηση', {'mode': 'search'}, icon='search')
    add_folder('Ρυθμίσεις', {'mode': 'settings'}, icon='settings')
    end(cache=False)
    intro_once()


def kids_root():
    """Λειτουργία Παιδιών: μόνο παιδικό περιεχόμενο· η έξοδος θέλει PIN."""
    add_folder('Παιδικά: Προστέθηκαν Πρόσφατα', {'mode': 'latest', 'days': 14, 'type': 'kids', 'sort': 'added'},
               icon='added')
    add_folder('Παιδικά: Τελευταία Εβδομάδα', {'mode': 'latest', 'days': 7, 'type': 'kids'}, icon='week')
    add_folder('Παιδικά: Όλες', {'mode': 'shows', 'type': 'kids'}, icon='kids')
    add_folder('Παιδικά: Α – Ω', {'mode': 'letters', 'type': 'kids'}, icon='letters')
    add_stream_item('kids')
    add_folder('Αναζήτηση', {'mode': 'search', 'type': 'kids'}, icon='search')
    li = xbmcgui.ListItem('Έξοδος Από Λειτουργία Παιδιών')
    li.setArt({'icon': media('exit'), 'thumb': media('exit'), 'fanart': FANART})
    xbmcplugin.addDirectoryItem(HANDLE, build_url(mode='kids_exit'), li, isFolder=False)
    end(cache=False)


def ask_pin(heading):
    try:
        return xbmcgui.Dialog().numeric(0, heading, '', True)
    except TypeError:
        return xbmcgui.Dialog().numeric(0, heading)


def kids_enter():
    """Ενεργοποίηση: ορισμός PIN 4 ψηφίων (δύο φορές, για επιβεβαίωση)."""
    pin = ask_pin('Λειτουργία Παιδιών — Νέο PIN (4 Ψηφία)')
    if not pin or len(pin) != 4 or not pin.isdigit():
        xbmcgui.Dialog().notification('Seriesly', 'Το PIN πρέπει να έχει 4 ψηφία', ICON, 3000)
        return
    if ask_pin('Επιβεβαίωση PIN') != pin:
        xbmcgui.Dialog().notification('Seriesly', 'Τα PIN δεν ταιριάζουν', ICON, 3000)
        return
    ADDON.setSetting('kids_pin', pin)
    ADDON.setSetting('kids_mode', 'true')
    xbmcgui.Dialog().notification('Seriesly', 'Λειτουργία Παιδιών: ενεργή', ICON, 3000)
    xbmc.executebuiltin('Container.Update(%s,replace)' % BASE_URL)


def kids_exit():
    pin = ask_pin('Έξοδος — PIN Λειτουργίας Παιδιών')
    if pin and pin == ADDON.getSetting('kids_pin'):
        ADDON.setSetting('kids_mode', 'false')
        xbmcgui.Dialog().notification('Seriesly', 'Λειτουργία Παιδιών: ανενεργή', ICON, 3000)
        xbmc.executebuiltin('Container.Update(%s,replace)' % BASE_URL)
    elif pin:
        xbmcgui.Dialog().notification('Seriesly', 'Λάθος PIN', ICON, 3000)


# ---------------------------------------------------------------- συνεχής ροή («κανάλια»)

STREAMS = (
    ('series', 'Κανάλι Σειρών'),
    ('show', 'Κανάλι Εκπομπών'),
    ('kids', 'Παιδικό Κανάλι'),
    ('sports', 'Αθλητικό Κανάλι'),
    ('favs', 'Από Τα Αγαπημένα Μου'),
)


def add_stream_item(kind):
    label = dict(STREAMS).get(kind, '')
    li = xbmcgui.ListItem('▶ ' + label)
    li.setArt({'icon': media('stream'), 'thumb': media('stream'), 'fanart': FANART})
    set_info(li, title=label, plot='Διάλεξε ολόκληρες σειρές ή συγκεκριμένα επεισόδια, και τη σειρά αναπαραγωγής — φτιάχνεις το '
                                    'δικό σου πρόγραμμα. Οι επιλογές σου μένουν για την επόμενη φορά. Στο τέλος η αναπαραγωγή σταματά.')
    xbmcplugin.addDirectoryItem(HANDLE, build_url(mode='stream', kind=kind), li, isFolder=False)


def streams():
    for kind, _ in STREAMS:
        if type_hidden(kind):
            continue
        add_stream_item(kind)
    end(cache=False)


ORDERS = (('alt', 'Εναλλάξ — 1 Από Κάθε Σειρά, Μετά Ξανά'),
          ('seq', 'Κατά Σειρά — Όλα Της 1ης, Μετά Της 2ης…'),
          ('date', 'Με Ημερομηνία — Παλαιότερο → Νεότερο'))
EPISODES_PER_SHOW = 5


def picks_file():
    folder = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    if not xbmcvfs.exists(folder):
        xbmcvfs.mkdirs(folder)
    return os.path.join(folder, 'streams.json')


def picks_load():
    try:
        with open(picks_file(), 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def picks_save(data):
    try:
        with open(picks_file(), 'w', encoding='utf-8') as fh:
            json.dump(data, fh, ensure_ascii=False)
    except OSError:
        log('δεν αποθηκεύτηκαν οι επιλογές της Συνεχούς Ροής', xbmc.LOGWARNING)


def sort_key(title):
    """Αλφαβητική σειρά χωρίς τόνους: πρώτα Ελληνικά (Α–Ω), μετά Λατινικά, μετά τα υπόλοιπα."""
    t = unicodedata.normalize('NFD', str(title).lower())
    t = ''.join(c for c in t if unicodedata.category(c) != 'Mn')
    t = re.sub(r'^[^\w]+', '', t)
    first = t[:1]
    group = 0 if '\u03b1' <= first <= '\u03c9' else (1 if first.isalpha() else 2)
    return (group, t)


def stream_shows(kind):
    """Οι σειρές/εκπομπές του «καναλιού»: [(channel, id, τίτλος, κανάλι-ετικέτα)] — ΟΛΕΣ, αλφαβητικά (Α–Ω)."""
    if kind == 'favs':
        found = [(x.get('channel'), x.get('id'), x.get('title', ''), '') for x in fav_visible()]
    else:
        found = []
        page, pages = 1, 1
        while page <= pages and page <= 8:
            data = api('/shows', type=kind, page=page, per_page=100) or {}
            pages = int(data.get('pages', 1) or 1)
            found += [(x.get('channel'), x.get('id'), x.get('title', ''), x.get('channel_label', ''))
                      for x in data.get('items', []) if int(x.get('episodes', 0)) > 0]
            page += 1
    return sorted(found, key=lambda x: sort_key(x[2]))


STREAM_MODES = (('whole', 'Ολόκληρες Σειρές/Εκπομπές — Τα 5 Τελευταία Επεισόδια Κάθε Μίας'),
                ('episodes', 'Συγκεκριμένα Επεισόδια — Διαλέγω Εγώ'))
EPISODE_CHOICES = 30   # πόσα πρόσφατα επεισόδια δείχνει κάθε σειρά στην επιλογή «Συγκεκριμένα Επεισόδια»
MAX_EPISODE_SHOWS = 8


def ask_multiselect(heading, labels, pre):
    try:
        return xbmcgui.Dialog().multiselect(heading, labels, preselect=pre)
    except TypeError:
        return xbmcgui.Dialog().multiselect(heading, labels)


def ask_select(heading, labels, pre):
    try:
        return xbmcgui.Dialog().select(heading, labels, preselect=pre)
    except TypeError:
        return xbmcgui.Dialog().select(heading, labels)


def stream_collect_episodes(shows, chosen):
    """Για κάθε σειρά που διάλεξε ο χρήστης: λίστα με τα πρόσφατα επεισόδιά της με τικ. Επιστρέφει per_show ή None (ακύρωση)."""
    per_show = []
    for n in chosen[:MAX_EPISODE_SHOWS]:
        c, i, t, _ = shows[n]
        res = api('/episodes', show=i, channel=c, page=1, per_page=EPISODE_CHOICES)
        eps = [e for e in (res or {}).get('items', []) if e.get('stream')]
        if not eps:
            continue
        labels = []
        for e in eps:
            shown, _aired = local_date(e.get('published'))
            title = e.get('title', '')
            labels.append(title if (not shown or shown in title) else '%s  (%s)' % (title, shown))
        picked = ask_multiselect('%s — Τίκαρε Επεισόδια' % t, labels, [])
        if picked is None:
            return None
        got = [eps[k] for k in picked]
        for e in got:
            e['_show'] = t
        if got:
            per_show.append(list(reversed(got)))   # μέσα στη σειρά: παλαιότερο → νεότερο
    return per_show


def stream(kind):
    """Συνεχής Ροή: ο χρήστης διαλέγει ΤΙ θα δει — ολόκληρες σειρές ή συγκεκριμένα επεισόδια — και με ποια σειρά. Τίποτα τυχαίο."""
    if kids_on() and kind != 'kids':
        return
    shows = stream_shows(kind)
    if not shows:
        xbmcgui.Dialog().notification('Seriesly', 'Δεν βρέθηκαν σειρές για αυτό το κανάλι', ICON, 4000)
        return
    memory = picks_load()
    saved = memory.get(kind, {})
    mode_ids = [m for m, _ in STREAM_MODES]
    m = ask_select('%s — Τι Να Παίξει;' % dict(STREAMS).get(kind, ''), [lab for _, lab in STREAM_MODES],
                   mode_ids.index(saved.get('mode')) if saved.get('mode') in mode_ids else 0)
    if m < 0:
        return
    mode = mode_ids[m]
    keys = ['%s:%s' % (c, i) for c, i, _, _ in shows]
    labels = [('%s  [%s]' % (t, lab)) if lab else t for _, _, t, lab in shows]
    mem_key = 'shows' if mode == 'whole' else 'ep_shows'
    pre = [n for n, k in enumerate(keys) if k in saved.get(mem_key, [])]
    heading = '%s — %s' % (dict(STREAMS).get(kind, ''),
                           'Τίκαρε Τι Θέλεις Να Δεις' if mode == 'whole' else 'Διάλεξε Σειρές — Μετά Θα Διαλέξεις Επεισόδια')
    chosen = ask_multiselect(heading, labels, pre)
    if chosen is None:
        return
    if not chosen:
        xbmcgui.Dialog().notification('Seriesly', 'Δεν τίκαρες καμία σειρά', ICON, 3000)
        return
    if mode == 'episodes' and len(chosen) > MAX_EPISODE_SHOWS:
        xbmcgui.Dialog().notification('Seriesly', 'Μέχρι %d σειρές τη φορά — πήρα τις πρώτες' % MAX_EPISODE_SHOWS, ICON, 4000)
    order_ids = [o for o, _ in ORDERS]
    last = order_ids.index(saved.get('order')) if saved.get('order') in order_ids else 0
    o = ask_select('Σειρά Αναπαραγωγής', [lab for _, lab in ORDERS], last)
    if o < 0:
        return
    if mode == 'whole':
        per_show = []
        for n in chosen[:25]:
            c, i, t, _ = shows[n]
            res = api('/episodes', show=i, channel=c, page=1, per_page=EPISODES_PER_SHOW)
            eps = [e for e in (res or {}).get('items', []) if e.get('stream')]
            for e in eps:
                e['_show'] = t
            per_show.append(list(reversed(eps)))   # μέσα στη σειρά: παλαιότερο → νεότερο
    else:
        per_show = stream_collect_episodes(shows, chosen)
        if per_show is None:
            return
    memory[kind] = dict(saved, mode=mode, order=order_ids[o])
    memory[kind][mem_key] = [keys[n] for n in chosen]
    picks_save(memory)
    items = playlist_order(per_show, order_ids[o])
    if not items:
        xbmcgui.Dialog().notification('Seriesly', 'Δεν βρέθηκαν επεισόδια', ICON, 4000)
        return
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playlist.clear()
    for e in items:
        label = '%s · %s' % (e.get('_show') or e.get('show_title', ''), e.get('title', ''))
        li = xbmcgui.ListItem(label)
        li.setArt(art(e.get('image', ''), e.get('show_poster', '')))
        li.setProperty('IsPlayable', 'true')
        set_info(li, title=label, plot=e.get('description', ''), mediatype='episode', show=e.get('_show', ''),
                 studio=e.get('channel_label', ''), duration=duration_of(e))
        playlist.add(build_url(mode='play', url=e.get('stream', '')), li)
    xbmc.Player().play(playlist)


def playlist_order(per_show, order):
    """alt: εναλλάξ · seq: σειρά-σειρά · date: όλα με ημερομηνία (παλαιότερο → νεότερο)."""
    if order == 'seq':
        return [e for eps in per_show for e in eps]
    if order == 'date':
        return sorted([e for eps in per_show for e in eps], key=lambda e: e.get('published') or '')
    out = []
    for k in range(max([len(eps) for eps in per_show] or [0])):
        for eps in per_show:
            if k < len(eps):
                out.append(eps[k])
    return out


def has_recent(ty, **params):
    """Υπάρχει έστω ένα επεισόδιο; Ρωτά ΤΟ ΙΔΙΟ με τη λίστα (ίδιες παράμετροι type/day/days/sort· και οι εξαιρέσεις xc/xt μπαίνουν μόνες τους). Αν ο κατάλογος δεν απαντά, δεν κρύβεται τίποτα."""
    data = api('/latest', type=ty, page=1, per_page=1, _quiet=True, **params)
    if data is None:
        return True
    return bool(data.get('items'))


def type_menu(ty):
    """Ένας τύπος (Σειρές / Εκπομπές / Ντοκιμαντέρ / Παιδικά / Αθλητικά): μόνο το δικό του περιεχόμενο."""
    name = TYPE_NAMES.get(ty, '')
    quiet = ty in HIDE_NO_RECENT
    if not quiet or has_recent(ty, days=14, sort='added'):
        add_folder('%s: Προστέθηκαν Πρόσφατα' % name, {'mode': 'latest', 'days': 14, 'type': ty, 'sort': 'added'},
                   plot='Επεισόδια που μπήκαν πρόσφατα στον κατάλογο — τα πιο πρόσφατα πρώτα', icon='added')
    week = (not quiet) or has_recent(ty, days=7)   # αν δεν υπάρχει τίποτα στην εβδομάδα, δεν υπάρχει ούτε σήμερα ούτε χθες
    if week and ((not quiet) or has_recent(ty, day='today')):
        add_folder('%s: Σήμερα' % name, {'mode': 'latest', 'day': 'today', 'type': ty}, icon='today')
    if week and ((not quiet) or has_recent(ty, day='yesterday')):
        add_folder('%s: Χθες' % name, {'mode': 'latest', 'day': 'yesterday', 'type': ty}, icon='yesterday')
    if week:
        add_folder('%s: Τελευταία Εβδομάδα' % name, {'mode': 'latest', 'days': 7, 'type': ty}, icon='week')
    if ty == 'series':
        year = datetime.now().year
        add_folder('Σειρές %d' % year, {'mode': 'shows', 'type': 'series', 'year': year, 'sort': 'recent'},
                   plot='Σειρές με επεισόδιο μέσα στο %d — πρώτες όσες ανέβασαν πιο πρόσφατα επεισόδιο' % year,
                   icon='year')
    add_folder('%s: Ανά Κανάλι' % name, {'mode': 'channels', 'type': ty}, icon='channels')
    add_folder('%s: Ανά Είδος' % name, {'mode': 'genres', 'type': ty}, icon='genres')
    add_folder('%s: Α – Ω' % name, {'mode': 'letters', 'type': ty}, icon='letters')
    add_folder('%s: Όλες' % name, {'mode': 'shows', 'type': ty}, icon='all')
    end(cache=False)


def channels(ty=''):
    data = api('/menu', type=ty)
    if data:
        for c in data.get('channels', []):
            add_folder('%s  (%d)' % (c.get('label', c.get('id')), int(c.get('shows', 0))),
                       {'mode': 'channel', 'channel': c.get('id'), 'title': c.get('label', ''), 'type': ty},
                       icon='channels')
    end(cache=False)


def youtube(cat=''):
    """Κανάλια → YouTube: κατηγορίες ανά είδος (Σειρές, Εκπομπές, Αθλητικά → Highlights → Basketball/Football, Παιδικά, Ταινίες,
    Συναυλίες, Podcasts) και μέσα τους οι εκπομπές. Φύλλο (χωρίς υποκατηγορίες) → κατευθείαν οι εκπομπές."""
    data = api('/menu', channel='youtube', cat=cat)
    if not data:
        end(cache=False)
        return
    yc = data.get('ycats') or {}
    items = yc.get('items') or []
    here = int(yc.get('here', 0) or 0)
    if not items:
        shows({'channel': 'youtube', 'cat': cat, 'catx': '1'})
        return
    if cat:
        add_folder('Όλα', {'mode': 'shows', 'channel': 'youtube', 'cat': cat}, icon='all',
                   plot='Όλες οι εκπομπές αυτής της κατηγορίας, μαζί με τις υποκατηγορίες της')
    for c in items:
        label = '%s  (%d)' % (c.get('label', ''), int(c.get('count', 0))) if opt('show_counts') == 'true' else c.get('label', '')
        add_folder(label, {'mode': 'youtube', 'cat': c.get('id')}, icon='genres')
    if here > 0:
        add_folder('Εκπομπές Αυτής Της Κατηγορίας  (%d)' % here, {'mode': 'shows', 'channel': 'youtube', 'cat': cat, 'catx': '1'},
                   icon='shows')
    end(cache=False)


def channel(ch, title, ty=''):
    if ch == 'youtube' and not ty:
        youtube('')
        return
    if ty:
        # Κανάλι μέσα σε έναν τύπο: πρόσφατα + όλες οι εκπομπές αυτού του τύπου.
        add_folder('%s: Τελευταία Εβδομάδα' % title, {'mode': 'latest', 'days': 7, 'channel': ch, 'type': ty}, icon='week')
        add_folder('%s: Όλες' % title, {'mode': 'shows', 'channel': ch, 'type': ty}, icon='all')
        end(cache=False)
        return
    add_folder('%s: Τελευταία Εβδομάδα' % title, {'mode': 'latest', 'days': 7, 'channel': ch}, icon='week')
    add_folder('%s: Όλες Οι Εκπομπές' % title, {'mode': 'shows', 'channel': ch}, icon='all')
    data = api('/menu')
    if data:
        for g in data.get('genres', []):
            add_folder('%s: %s' % (title, g.get('label', '')), {'mode': 'shows', 'channel': ch, 'genre': g.get('id')},
                       icon='genres')
    end(cache=False)


def genres(ty=''):
    data = api('/menu', type=ty)
    if data:
        for g in data.get('genres', []):
            if int(g.get('shows', 0)) <= 0:
                continue
            add_folder('%s  (%d)' % (g.get('label', ''), int(g.get('shows', 0))),
                       {'mode': 'shows', 'genre': g.get('id'), 'type': ty}, icon='genres')
    end(cache=False)


def letters(ty=''):
    data = api('/menu', type=ty)
    if data:
        for item in data.get('letters', []):
            letter = item.get('letter', '')
            add_folder('%s  (%d)' % (letter, int(item.get('shows', 0))), {'mode': 'shows', 'letter': letter, 'type': ty})
    end(cache=False)


def shows(query):
    page = int(query.get('page', 1))
    sort = query.get('sort') or ('recent' if opt('show_sort') == 'recent' else None)
    data = api('/shows', channel=query.get('channel'), genre=query.get('genre'),
               letter=query.get('letter'), q=query.get('q'), type=query.get('type'),
               year=query.get('year'), cat=query.get('cat'), catx=query.get('catx'), sort=sort, page=page, per_page=per_page())
    if data:
        many_channels = not query.get('channel')
        favs = fav_keys()
        for s in data.get('items', []):
            label = s.get('title', '')
            if fav_key(s.get('channel'), s.get('id')) in favs:
                label = '★ ' + label
            if many_channels:
                label += channel_tag(s)
            count = int(s.get('episodes', 0))
            if count > 0:
                last, _ = local_date(s.get('last'))
                plot = '%d %s%s' % (count, 'επεισόδιο' if count == 1 else 'επεισόδια',
                                    (' · τελευταίο %s' % last) if last else '')
                add_folder(label, {'mode': 'episodes', 'show': s.get('id'), 'channel': s.get('channel'),
                                   'title': s.get('title', '')},
                           thumb=s.get('image', ''), poster=s.get('poster', ''), plot=plot,
                           menu=fav_menu(s.get('channel'), s.get('id'), s.get('title', ''),
                                         s.get('image', ''), s.get('poster', '')))
            elif s.get('stream'):
                add_playable(label, s['stream'], thumb=s.get('image', ''), poster=s.get('poster', ''),
                             show=s.get('title', ''), genres=genre_labels(s.get('genres')),
                             studio=s.get('channel_label', ''))
        base = dict((k, v) for k, v in query.items() if k in ('mode', 'channel', 'genre', 'letter', 'q', 'type', 'year', 'sort', 'cat', 'catx'))
        base['mode'] = 'shows'
        add_next_page(data, base)
    end('tvshows')


def episodes(query):
    page = int(query.get('page', 1))
    data = api('/episodes', show=query.get('show'), channel=query.get('channel'), page=page, per_page=per_page())
    if data:
        first = (data.get('items') or [{}])[0]
        if page == 1 and query.get('show') and not kids_on():
            add_fav_toggle(query, first.get('show_poster', ''))
        for e in data.get('items', []):
            shown, aired = local_date(e.get('published'))
            title = e.get('title', '')
            label = title if (not shown or shown in title) else '%s  (%s)' % (title, shown)
            add_playable(label, e.get('stream', ''), thumb=e.get('image', ''), poster=e.get('show_poster', ''),
                         plot=e.get('description', ''), aired=aired, show=e.get('show_title', ''),
                         genres=genre_labels(e.get('genres')), studio=e.get('channel_label', ''),
                         duration=duration_of(e),
                         menu=fav_menu(query.get('channel'), query.get('show'), query.get('title', ''),
                                       poster=e.get('show_poster', '')))
        add_next_page(data, {'mode': 'episodes', 'show': query.get('show'), 'channel': query.get('channel'),
                             'title': query.get('title', '')})
    end('episodes')


def latest(query):
    page = int(query.get('page', 1))
    data = api('/latest', day=query.get('day'), days=query.get('days'), channel=query.get('channel'),
               genre=query.get('genre'), type=query.get('type'), sort=query.get('sort'), page=page, per_page=per_page())
    if data:
        for e in data.get('items', []):
            shown, aired = local_date(e.get('published'))
            show = e.get('show_title', '')
            label = '%s · %s' % (show, e.get('title', '')) if show else e.get('title', '')
            if not query.get('channel'):
                label += channel_tag(e)
            add_playable(label, e.get('stream', ''), thumb=e.get('image', ''), poster=e.get('show_poster', ''),
                         plot=e.get('description', ''), aired=aired, show=show,
                         genres=genre_labels(e.get('genres')), studio=e.get('channel_label', ''),
                         duration=duration_of(e),
                         menu=fav_menu(e.get('channel'), e.get('show_id'), show, poster=e.get('show_poster', '')))
        if not data.get('items'):
            xbmcgui.Dialog().notification('Seriesly', 'Δεν υπάρχουν επεισόδια για αυτό το διάστημα', ICON, 4000)
        base = dict((k, v) for k, v in query.items() if k in ('mode', 'day', 'days', 'channel', 'genre', 'type', 'sort'))
        add_next_page(data, base)
    end('episodes', cache=False)


def search(ty=''):
    kb = xbmc.Keyboard('', 'Αναζήτηση Σειράς Ή Εκπομπής')
    kb.doModal()
    if not kb.isConfirmed():
        end(cache=False)
        return
    text = kb.getText().strip()
    if not text:
        end(cache=False)
        return
    shows({'mode': 'shows', 'q': text, 'type': ty} if ty else {'mode': 'shows', 'q': text})


ABOUT_TITLE = 'Καλώς Ήρθες Στο Seriesly'
ABOUT_TEXT = (
    '[B]Τι είναι το Seriesly[/B]\n'
    'Το Seriesly οργανώνει σε έναν ενιαίο, εύχρηστο κατάλογο τις σειρές, τις εκπομπές, τα παιδικά και τα αθλητικά '
    'προγράμματα που τα ίδια τα ελληνικά τηλεοπτικά κανάλια διαθέτουν δημόσια και δωρεάν στους επίσημους '
    'ιστότοπούς τους.\n\n'
    '[B]Από πού προέρχεται το περιεχόμενο[/B]\n'
    'Αποκλειστικά από τις επίσημες σελίδες των καναλιών: MEGA, ANT1, Alpha, ΣΚΑΪ, STAR και OPEN. Ο κατάλογος '
    'διαβάζει τα δημόσια ευρετήρια (sitemaps) και τις σελίδες σειρών τους, όπως κάνει κάθε μηχανή αναζήτησης, '
    'σεβόμενος τους κανόνες (robots.txt) κάθε ιστότοπου.\n\n'
    '[B]Πώς παίζουν τα βίντεο[/B]\n'
    'Κάθε επεισόδιο παίζει απευθείας από τους servers του καναλιού στο οποίο ανήκει — ακριβώς όπως στον δικό του '
    'ιστότοπο. Το Seriesly δεν φιλοξενεί, δεν αποθηκεύει, δεν αντιγράφει και δεν αναμεταδίδει κανένα βίντεο.\n\n'
    '[B]Τι δεν περιλαμβάνεται[/B]\n'
    '• Περιεχόμενο με τεχνική προστασία αντιγραφής (DRM) ή από συνδρομητικές υπηρεσίες\n'
    '• Ζωντανές μεταδόσεις\n'
    '• Δελτία ειδήσεων\n'
    'Όπου ένα κανάλι διαθέτει ένα επεισόδιο μόνο στην Ελλάδα, το βίντεο το ζητά η δική σου συσκευή, όπως στον '
    'ιστότοπο του καναλιού — κανένας περιορισμός δεν παρακάμπτεται.\n\n'
    '[B]Διαθεσιμότητα[/B]\n'
    'Τα νέα επεισόδια εμφανίζονται συνήθως μέσα σε περίπου μία ώρα αφότου τα ανεβάσει το κανάλι. Η διαθεσιμότητα '
    'κάθε επεισοδίου εξαρτάται αποκλειστικά από το κανάλι που το διαθέτει.\n\n'
    '[B]Πνευματικά δικαιώματα[/B]\n'
    'Όλα τα δικαιώματα ανήκουν στους νόμιμους δικαιούχους — τα κανάλια και τους παραγωγούς. Ονόματα, λογότυπα και '
    'εικόνες εμφανίζονται μόνο για την αναγνώριση του περιεχομένου.\n\n'
    '[B]Χρήση[/B]\n'
    'Προσωπική, μη εμπορική, χωρίς καμία χρέωση.\n\n'
    '[I]Μπορείς να ξαναδείς αυτό το κείμενο από τις Ρυθμίσεις του πρόσθετου. '
    'Πάτα «Πίσω» ή «OK» για να συνεχίσεις.[/I]'
)


def favourites():
    """★ Αγαπημένα: «Νέα Επεισόδια» και οι αγαπημένες σειρές/εκπομπές (χωρίς όσα ανήκουν σε κρυμμένο κανάλι)."""
    items = fav_visible()
    if not items:
        add_folder('Δεν Έχεις Αγαπημένα Ακόμα — Πώς Προσθέτω;', {'mode': 'fav_help'}, icon='info')
        end(cache=False)
        return
    add_folder('Νέα Επεισόδια', {'mode': 'fav_new'}, icon='added',
               plot='Τα πιο πρόσφατα επεισόδια από τα αγαπημένα σου')
    for x in sorted(items, key=lambda i: i.get('title', '')):
        add_folder(x.get('title', ''), {'mode': 'episodes', 'show': x.get('id'), 'channel': x.get('channel'),
                                        'title': x.get('title', '')},
                   thumb=x.get('image', ''), poster=x.get('poster', ''),
                   menu=fav_menu(x.get('channel'), x.get('id'), x.get('title', '')))
    end('tvshows', cache=False)


def fav_new():
    """Νέα επεισόδια από τα αγαπημένα (τα 5 νεότερα κάθε σειράς, όλα μαζί με ημερομηνία)."""
    found = []
    for x in fav_visible()[:30]:
        data = api('/episodes', show=x.get('id'), channel=x.get('channel'), page=1, per_page=5)
        for e in (data or {}).get('items', []):
            e['_show'] = x.get('title', '')
            found.append(e)
    found.sort(key=lambda e: e.get('published') or '', reverse=True)
    for e in found[:60]:
        shown, aired = local_date(e.get('published'))
        label = '%s · %s' % (e['_show'], e.get('title', '')) + channel_tag(e)
        add_playable(label, e.get('stream', ''), thumb=e.get('image', ''), poster=e.get('show_poster', ''),
                     plot=e.get('description', ''), aired=aired, show=e['_show'],
                     genres=genre_labels(e.get('genres')), studio=e.get('channel_label', ''), duration=duration_of(e))
    if not found:
        xbmcgui.Dialog().notification('Seriesly', 'Δεν βρέθηκαν επεισόδια', ICON, 4000)
    end('episodes', cache=False)


def fav_add(query):
    if not query.get('show') or query.get('show') == 'None':
        xbmcgui.Dialog().notification('Seriesly', 'Δεν βρέθηκε η σειρά για προσθήκη', ICON, 3000)
        return
    items = fav_load()
    if fav_key(query.get('channel'), query.get('show')) not in fav_keys():
        items.append({'id': query.get('show'), 'channel': query.get('channel'), 'title': query.get('title', ''),
                      'image': query.get('image', ''), 'poster': query.get('poster', '')})
        if not fav_save(items):
            xbmcgui.Dialog().ok('Seriesly', 'Δεν μπόρεσε να αποθηκευτεί το αγαπημένο.\n'
                                            'Δοκίμασε ξανά ή κάνε επανεκκίνηση του Kodi.')
            return
    xbmcgui.Dialog().notification('Seriesly', '★ Προστέθηκε Στα Αγαπημένα', ICON, 2500)
    xbmc.executebuiltin('Container.Refresh')


def fav_del(query):
    key = fav_key(query.get('channel'), query.get('show'))
    if not fav_save([x for x in fav_load() if fav_key(x.get('channel'), x.get('id')) != key]):
        xbmcgui.Dialog().ok('Seriesly', 'Δεν μπόρεσε να αφαιρεθεί το αγαπημένο.\nΔοκίμασε ξανά ή κάνε επανεκκίνηση του Kodi.')
        return
    xbmcgui.Dialog().notification('Seriesly', 'Αφαιρέθηκε Από Τα Αγαπημένα', ICON, 2500)
    xbmc.executebuiltin('Container.Refresh')


def add_fav_toggle(query, poster=''):
    """Ορατή γραμμή στην κορυφή της σειράς: προσθήκη/αφαίρεση από τα Αγαπημένα (χωρίς παρατεταμένο πάτημα)."""
    channel, show_id = query.get('channel'), query.get('show')
    on = fav_key(channel, show_id) in fav_keys()
    li = xbmcgui.ListItem('★ Αφαίρεση Της Σειράς Από Τα Αγαπημένα' if on else '☆ Προσθήκη Της Σειράς Στα Αγαπημένα')
    li.setArt({'icon': media('favourites'), 'thumb': media('favourites'), 'fanart': FANART})
    if on:
        url = build_url(mode='fav_del', channel=channel, show=show_id)
    else:
        url = build_url(mode='fav_add', channel=channel, show=show_id, title=query.get('title', ''), poster=poster)
    xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)


def fav_help():
    xbmcgui.Dialog().ok('Αγαπημένα', 'Πάτα [B]παρατεταμένα[/B] το OK του τηλεχειριστηρίου (ή δεξί κλικ) πάνω σε μια '
                                     'σειρά ή ένα επεισόδιο και διάλεξε [B]«☆ Προσθήκη Στα Αγαπημένα»[/B].\n'
                                     'Θα τη βρίσκεις εδώ, μαζί με τα νέα της επεισόδια.')


def schedule():
    """Σημερινό Πρόγραμμα: παράθυρο καναλιών → παράθυρο προγράμματος (Πίσω = ένα βήμα πίσω, χωρίς να φύγεις)."""
    data = api('/schedule')
    chans = [c for c in (data or {}).get('channels', []) if not channel_hidden(c.get('id'))]
    if not chans:
        xbmcgui.Dialog().notification('Seriesly', 'Το πρόγραμμα δεν είναι διαθέσιμο αυτή τη στιγμή', ICON, 4000)
        return
    while True:
        pick = xbmcgui.Dialog().select('Σημερινό Πρόγραμμα — Διάλεξε Κανάλι', [c.get('label', '') for c in chans])
        if pick < 0:
            return
        if schedule_channel(chans[pick]):
            return


def schedule_channel(chan):
    """Το πρόγραμμα ενός καναλιού. True = ο χρήστης άνοιξε εκπομπή (τέλος)· False = Πίσω στα κανάλια."""
    data = api('/schedule', channel=chan.get('id'))
    items = (data or {}).get('items', [])
    if not items:
        xbmcgui.Dialog().notification('Seriesly', 'Δεν βρέθηκε πρόγραμμα για %s' % chan.get('label', ''), ICON, 4000)
        return False
    lines, now = [], 0
    for i, it in enumerate(items):
        time_ = ('~' if it.get('approx') else '') + (it.get('time') or '—:—')
        mark = '▶ ' if it.get('show_id') else '    '
        line = '%s   %s%s' % (time_, mark, it.get('title', ''))
        if it.get('now'):
            now = i
            line = '[B]%s   · ΤΩΡΑ[/B]' % line
        lines.append(line)
    day = (data or {}).get('date', '')
    heading = '%s — Πρόγραμμα %s' % (chan.get('label', ''), '/'.join(reversed(day.split('-')[1:])) if day else '')
    while True:
        try:
            pick = xbmcgui.Dialog().select(heading, lines, preselect=now)
        except TypeError:
            pick = xbmcgui.Dialog().select(heading, lines)
        if pick < 0:
            return False
        it = items[pick]
        if it.get('show_id'):
            xbmc.executebuiltin('Container.Update(%s)' % build_url(mode='episodes', show=it.get('show_id'),
                                                                     channel=chan.get('id'),
                                                                     title=it.get('show_title') or it.get('title', '')))
            return True
        xbmcgui.Dialog().notification('Seriesly', 'Αυτό το πρόγραμμα δεν υπάρχει (ακόμα) στο Seriesly', ICON, 3000)
        now = pick


def pick_types():
    """Ρυθμίσεις → Περιεχόμενο → Κατηγορίες: τικάρεις ό,τι θέλεις να ΒΛΕΠΕΙΣ· ό,τι ξετικάρεις κρύβεται."""
    hidden = hidden_list('hide_types')
    pre = [n for n, (tid, _) in enumerate(TYPES) if tid not in hidden]
    chosen = ask_multiselect('Κατηγορίες — Τικαρισμένες = Ορατές', [label for _, label in TYPES], pre)
    if chosen is None:
        return
    ADDON.setSetting('hide_types', ','.join(tid for n, (tid, _) in enumerate(TYPES) if n not in chosen))
    xbmc.executebuiltin('Container.Refresh')


def pick_channels():
    """Ρυθμίσεις → Περιεχόμενο → Κανάλια: η λίστα έρχεται ζωντανά (ΟΛΑ τα κανάλια, με _raw)· ό,τι ξετικάρεις κρύβεται."""
    data = api('/menu', _raw=1)
    chans = sorted([(c.get('id'), c.get('label', '')) for c in (data or {}).get('channels', []) if c.get('id')],
                   key=lambda x: sort_key(x[1]))
    if not chans:
        xbmcgui.Dialog().notification('Seriesly', 'Δεν φορτώθηκαν τα κανάλια', ICON, 4000)
        return
    hidden = hidden_list('hide_channels')
    pre = [n for n, (cid, _) in enumerate(chans) if cid not in hidden]
    chosen = ask_multiselect('Κανάλια — Τικαρισμένα = Ορατά', [label for _, label in chans], pre)
    if chosen is None:
        return
    ADDON.setSetting('hide_channels', ','.join(cid for n, (cid, _) in enumerate(chans) if n not in chosen))
    xbmc.executebuiltin('Container.Refresh')


def settings_menu():
    add_folder('Εμφάνιση', {'mode': 'settings_group', 'group': 'appearance'}, icon='appearance',
               plot='Πώς φαίνεται το πρόσθετο')
    add_folder('Λειτουργία', {'mode': 'settings_group', 'group': 'functions'}, icon='functions',
               plot='Πώς δουλεύει το πρόσθετο')
    add_folder('Περιεχόμενο', {'mode': 'settings_group', 'group': 'content'}, icon='functions',
               plot='Ποια κανάλια και κατηγορίες βλέπεις — και αν εμφανίζεται η Συνεχής Ροή')
    end(cache=False)


def settings_group(group):
    """Κάθε ρύθμιση μία γραμμή: «Τίτλος: Τιμή» — ένα πάτημα την αλλάζει."""
    keys = APPEARANCE if group == 'appearance' else (CONTENT if group == 'content' else FUNCTIONS)
    icon = 'appearance' if group == 'appearance' else 'functions'
    if group == 'content':
        hid_t = len(hidden_list('hide_types'))
        hid_c = len(hidden_list('hide_channels'))
        for title, value, mode in (('Κατηγορίες Που Εμφανίζονται', 'Όλες' if not hid_t else 'Κρυμμένες: %d' % hid_t, 'pick_types'),
                                   ('Κανάλια Που Εμφανίζονται', 'Όλα' if not hid_c else 'Κρυμμένα: %d' % hid_c, 'pick_channels')):
            li = xbmcgui.ListItem('%s: [B]%s[/B]' % (title, value))
            li.setArt({'icon': media('functions'), 'thumb': media('functions'), 'fanart': FANART})
            xbmcplugin.addDirectoryItem(HANDLE, build_url(mode=mode), li, isFolder=False)
    for key in keys:
        li = xbmcgui.ListItem('%s: [B]%s[/B]' % (OPTIONS[key][0], opt_label(key)))
        own = KEY_ICONS.get(key[:5], KEY_ICONS.get(key, icon))
        li.setArt({'icon': media(own), 'thumb': media(own), 'fanart': FANART})
        xbmcplugin.addDirectoryItem(HANDLE, build_url(mode='toggle', key=key), li, isFolder=False)
    if group == 'functions':
        add_folder('Πληροφορίες & Κατάσταση', {'mode': 'status'}, icon='info')
        add_folder('Τι Είναι Το Seriesly', {'mode': 'about'}, icon='info')
    end(cache=False)


def toggle(key):
    """Επόμενη τιμή της ρύθμισης (κυκλικά) και ανανέωση της οθόνης."""
    if key not in OPTIONS:
        return
    if key == 'kids_mode':
        kids_enter()
        return
    values = [v for v, _ in OPTIONS[key][1]]
    ADDON.setSetting(key, values[(values.index(opt(key)) + 1) % len(values)])
    xbmc.executebuiltin('Container.Refresh')


def status():
    """Πληροφορίες & Κατάσταση: έκδοση, αν απαντά ο κατάλογος, πλήθη, τελευταίο επεισόδιο."""
    lines = ['[B]Seriesly[/B] %s' % VERSION]
    data = api('/menu')
    if data:
        lines.append('Κατάλογος: [COLOR FF27AE60]απαντά κανονικά[/COLOR]')
        for tid, label in TYPES:
            n = next((int(t.get('shows', 0)) for t in data.get('types', []) if t.get('id') == tid), 0)
            lines.append('%s: %d' % (label, n))
        chans = ', '.join(c.get('label', '') for c in data.get('channels', []))
        if chans:
            lines.append('Κανάλια: %s' % chans)
        last = api('/latest', days=2, sort='added', page=1, per_page=1)
        items = (last or {}).get('items', [])
        if items:
            when, _ = local_date(items[0].get('added') or items[0].get('published'))
            lines.append('Τελευταίο επεισόδιο: %s · %s (%s)' % (items[0].get('show_title', ''),
                                                            items[0].get('title', ''), when))
    else:
        lines.append('Κατάλογος: [COLOR FFEB5757]δεν απαντά[/COLOR] — δοκίμασε ξανά σε λίγο')
    lines.append('Αγαπημένα: %d' % len(fav_load()))
    xbmcgui.Dialog().textviewer('Πληροφορίες & Κατάσταση', '\n'.join(lines))


def about():
    xbmcgui.Dialog().textviewer(ABOUT_TITLE, ABOUT_TEXT)


INTRO_REV = '2'   # αλλάζει όταν αλλάζει το κείμενο: το παράθυρο εμφανίζεται ξανά μία φορά (1.3.0: στατιστικά χρήσης)


def intro_once():
    """Την πρώτη φορά που ανοίγει το πρόσθετο — και μία φορά ξανά όταν αλλάζει το κείμενο: πλήρης εξήγηση."""
    if ADDON.getSetting('intro_rev') == INTRO_REV:
        return
    ADDON.setSetting('intro_rev', INTRO_REV)
    about()


ANT1_PLAYER = 'https://www.antenna.gr/templates/data/PlayerDataGraphQL_v2?cid='


def resolve_ant1(code):
    """ANT1 με περιορισμό χώρας: ρωτά τον player του ANT1 ΑΠΟ ΑΥΤΗ ΤΗ ΣΥΣΚΕΥΗ (Ελλάδα), όπως το antenna.gr.
    Επιστρέφει τη διεύθυνση του βίντεο ή '' («NO GR» / σφάλμα)."""
    try:
        req = Request(ANT1_PLAYER + code, headers={'User-Agent': 'Mozilla/5.0 (Kodi) Seriesly'})
        with urlopen(req, timeout=15) as res:
            data = json.loads(res.read().decode('utf-8'))
    except (URLError, HTTPError, ValueError, OSError):
        return ''
    video = data.get('url', '') if isinstance(data, dict) else ''
    if not isinstance(video, str):
        return ''
    if video.startswith('//'):
        video = 'https:' + video
    low = video.lower().split('?')[0]
    if not video.startswith('https://') or 'nogr' in low or not low.endswith(('.mp4', '.m3u8')):
        return ''
    return video


YOUTUBE_ADDON = 'plugin.video.youtube'


def resolve_youtube(code):
    """«youtube:ΚΩΔΙΚΟΣ» → διεύθυνση του πρόσθετου YouTube του Kodi (το εγκαθιστά ο χρήστης από το επίσημο αποθετήριο).
    Επιστρέφει '' αν ο κωδικός είναι άκυρος ή αν λείπει το πρόσθετο (με μήνυμα προς τον χρήστη)."""
    if not re.match(r'^[A-Za-z0-9_\-]{6,20}$', code or ''):
        return ''
    if not xbmc.getCondVisibility('System.HasAddon(%s)' % YOUTUBE_ADDON):
        xbmcgui.Dialog().ok('Seriesly', 'Για τα βίντεο του YouTube χρειάζεται το πρόσθετο «YouTube» του Kodi.\n'
                                        'Εγκατάσταση: Πρόσθετα → Εγκατάσταση από αποθετήριο → Πρόσθετα βίντεο → YouTube.')
        return ''
    return 'plugin://%s/play/?video_id=%s' % (YOUTUBE_ADDON, code)


def play(url):
    if url.startswith('ant1:'):
        url = resolve_ant1(url[5:])
        if not url:
            xbmcgui.Dialog().notification('Seriesly', 'Ο ANT1 δεν διαθέτει αυτό το επεισόδιο online αυτή τη στιγμή.',
                                          xbmcgui.NOTIFICATION_INFO, 5000)
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            return
    elif url.startswith('youtube:'):
        url = resolve_youtube(url[8:])
        if not url:
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            return
    li = xbmcgui.ListItem(path=url)
    low = url.lower().split('?')[0]
    if low.endswith('.m3u8'):
        li.setMimeType('application/vnd.apple.mpegurl')
        li.setContentLookup(False)
    elif low.endswith('.mp4'):
        li.setMimeType('video/mp4')
        li.setContentLookup(False)
    xbmcplugin.setResolvedUrl(HANDLE, bool(url), li)


# ---------------------------------------------------------------- δρομολόγηση

KIDS_MODES = (None, 'type', 'channels', 'channel', 'genres', 'letters', 'shows', 'episodes', 'latest', 'search',
              'play', 'stream', 'kids_exit', 'about')


VIEW_REV = '2'


def migrate_views():
    """1.6.0: προεπιλογή «Λίστα» παντού. ΜΙΑ φορά αντικαθιστά ό,τι είχε αποθηκευτεί (π.χ. «Αφίσες»)· μετά ισχύει ό,τι διαλέξει ο χρήστης."""
    if ADDON.getSetting('view_rev') == VIEW_REV:
        return
    for key in ('view_menus', 'view_shows', 'view_episodes'):
        ADDON.setSetting(key, '50')
    ADDON.setSetting('view_rev', VIEW_REV)


def router(query):
    migrate_views()
    migrate_api()
    mode = query.get('mode')
    if kids_on():
        if mode not in KIDS_MODES:
            xbmcgui.Dialog().notification('Seriesly', 'Κλειδωμένο στη Λειτουργία Παιδιών', ICON, 3000)
            mode = None
        elif mode not in (None, 'episodes', 'play', 'stream', 'kids_exit', 'about', 'channel'):
            query['type'] = 'kids'   # όλες οι λίστες: μόνο παιδικά
        elif mode == 'channel':
            query['type'] = 'kids'
    if mode is None:
        root()
    elif mode == 'type':
        type_menu(query.get('type', ''))
    elif mode == 'channels':
        channels(query.get('type', ''))
    elif mode == 'channel':
        channel(query.get('channel', ''), query.get('title', ''), query.get('type', ''))
    elif mode == 'youtube':
        youtube(query.get('cat', ''))
    elif mode == 'genres':
        genres(query.get('type', ''))
    elif mode == 'letters':
        letters(query.get('type', ''))
    elif mode == 'about':
        about()
    elif mode == 'favs':
        favourites()
    elif mode == 'fav_new':
        fav_new()
    elif mode == 'fav_add':
        fav_add(query)
    elif mode == 'fav_del':
        fav_del(query)
    elif mode == 'fav_help':
        fav_help()
    elif mode == 'settings':
        settings_menu()
    elif mode == 'settings_group':
        settings_group(query.get('group', ''))
    elif mode == 'toggle':
        toggle(query.get('key', ''))
    elif mode == 'pick_types':
        pick_types()
    elif mode == 'pick_channels':
        pick_channels()
    elif mode == 'status':
        status()
    elif mode == 'streams':
        streams()
    elif mode == 'schedule':
        schedule()
    elif mode == 'stream':
        stream(query.get('kind', ''))
    elif mode == 'kids_exit':
        kids_exit()
    elif mode == 'shows':
        shows(query)
    elif mode == 'episodes':
        episodes(query)
    elif mode == 'latest':
        latest(query)
    elif mode == 'search':
        search(query.get('type', ''))
    elif mode == 'play':
        play(query.get('url', ''))
    else:
        log('άγνωστο mode: %s' % mode, xbmc.LOGWARNING)
        root()


if __name__ == '__main__':
    router(ARGS)
