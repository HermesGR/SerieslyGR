# -*- coding: utf-8 -*-
"""
Seriesly - Ελληνική TV από τα επίσημα sites των καναλιών.

Διαβάζει τον κατάλογο από το API του καταλόγου (WordPress) και παίζει
τα βίντεο απευθείας από τους servers των καναλιών. Δεν κάνει scraping το ίδιο.
"""
import os
import re
import sys
import json
import time
from datetime import datetime
from urllib.parse import urlencode, parse_qsl
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon()
VERSION = ADDON.getAddonInfo('version')
ICON = ADDON.getAddonInfo('icon')
FANART = ADDON.getAddonInfo('fanart')
MEDIA = os.path.join(ADDON.getAddonInfo('path'), 'resources', 'media')


def media(name):
    """Εικονίδιο στο θέμα που διάλεξε ο χρήστης (resources/media/ΘΕΜΑ/ΟΝΟΜΑ.png)· ίδια σχήματα σε όλα τα θέματα."""
    path = os.path.join(MEDIA, opt('icon_theme'), name + '.png')
    return path if os.path.exists(path) else os.path.join(MEDIA, 'seriesly', name + '.png')
DEFAULT_API = 'https://e-menucms.gr/wp-json/dp82tube/v1'

BASE_URL = sys.argv[0]
HANDLE = int(sys.argv[1])
ARGS = dict(parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}


# ---------------------------------------------------------------- βοηθητικά

# ---------------------------------------------------------------- ρυθμίσεις (ένα πάτημα)

# Προβολές του Estuary (το προεπιλεγμένο skin του Kodi): Αφίσες 51 (προεπιλογή) · Λίστα 50 · Ευρεία Λίστα 55 · Τοίχος 500.
VIEWS = [('51', 'Αφίσες'), ('50', 'Λίστα'), ('55', 'Ευρεία Λίστα'), ('500', 'Τοίχος'), ('auto', 'Αυτόματη')]
# κλειδί: (τίτλος, [(τιμή, ετικέτα)…]) — η πρώτη τιμή είναι η προεπιλογή.
OPTIONS = {
    'show_channel':  ('Κανάλι Δίπλα Στον Τίτλο', [('true', 'Ναι'), ('false', 'Όχι')]),
    'color_channel': ('Χρώμα Καναλιού', [('true', 'Ναι'), ('false', 'Όχι')]),
    'show_sort':     ('Ταξινόμηση Εκπομπών', [('alpha', 'Αλφαβητικά'), ('recent', 'Πιο Πρόσφατες Πρώτα')]),
    'show_counts':   ('Πλήθος Δίπλα Στις Κατηγορίες', [('true', 'Ναι'), ('false', 'Όχι')]),
    'per_page':      ('Επεισόδια Ανά Σελίδα', [('50', '50'), ('25', '25'), ('100', '100')]),
    'icon_theme':    ('Θέμα Εικονιδίων', [('seriesly', 'Seriesly'), ('color', 'Πολύχρωμο'), ('mono', 'Σκούρο'),
                                          ('light', 'Φωτεινό')]),
    'view_menus':    ('Προβολή Μενού', VIEWS),
    'view_shows':    ('Προβολή Εκπομπών', VIEWS),
    'view_episodes': ('Προβολή Επεισοδίων', VIEWS),
    'stats_on':      ('Αποστολή Στατιστικών Χρήσης', [('true', 'Ναι'), ('false', 'Όχι')]),
    'kids_mode':     ('Λειτουργία Παιδιών', [('false', 'Όχι'), ('true', 'Ναι')]),
}
KEY_ICONS = {'icon_theme': 'theme', 'view_': 'view', 'kids_mode': 'kidslock', 'stats_on': 'info'}
APPEARANCE = ('icon_theme', 'view_menus', 'view_shows', 'view_episodes', 'show_channel', 'color_channel',
              'show_sort', 'show_counts')
FUNCTIONS = ('per_page', 'stats_on', 'kids_mode')
CHANNEL_COLORS = {'mega': 'FFE8453C', 'alpha': 'FF4FA3F7', 'skai': 'FF2F80ED', 'open': 'FFF2994A', 'star': 'FFF2C94C',
                  'ant1': 'FFEB5757', 'ert': 'FF27AE60'}


def opt(key):
    """Τρέχουσα τιμή ρύθμισης (αν δεν έχει οριστεί ή είναι άκυρη: η προεπιλογή)."""
    values = [v for v, _ in OPTIONS[key][1]]
    value = ADDON.getSetting(key)
    return value if value in values else values[0]


def opt_label(key):
    return dict(OPTIONS[key][1])[opt(key)]


def channel_tag(item):
    """«  [MEGA]» δίπλα στον τίτλο — με χρώμα ανά κανάλι, αν είναι ενεργό."""
    if opt('show_channel') != 'true':
        return ''
    name = item.get('channel_label', '')
    color = CHANNEL_COLORS.get(item.get('channel', ''), '')
    if color and opt('color_channel') == 'true':
        return '  [COLOR %s][%s][/COLOR]' % (color, name)
    return '  [%s]' % name


# ---------------------------------------------------------------- αγαπημένα (αρχείο στο προφίλ του πρόσθετου)

def fav_file():
    folder = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    if not xbmcvfs.exists(folder):
        xbmcvfs.mkdirs(folder)
    return os.path.join(folder, 'favourites.json')


def fav_load():
    try:
        with open(fav_file(), 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        return data if isinstance(data, list) else []
    except (OSError, ValueError):
        return []


def fav_save(items):
    try:
        with open(fav_file(), 'w', encoding='utf-8') as fh:
            json.dump(items, fh, ensure_ascii=False)
    except OSError:
        log('δεν αποθηκεύτηκαν τα αγαπημένα', xbmc.LOGWARNING)


def fav_key(channel, show_id):
    return '%s:%s' % (channel, show_id)


def fav_keys():
    return set(fav_key(x.get('channel'), x.get('id')) for x in fav_load())


def fav_menu(channel, show_id, title, image='', poster=''):
    """Μενού (παρατεταμένο πάτημα / δεξί κλικ): προσθήκη ή αφαίρεση από τα Αγαπημένα."""
    if fav_key(channel, show_id) in fav_keys():
        return [('★ Αφαίρεση Από Τα Αγαπημένα',
                 'RunPlugin(%s)' % build_url(mode='fav_del', channel=channel, show=show_id))]
    return [('☆ Προσθήκη Στα Αγαπημένα',
             'RunPlugin(%s)' % build_url(mode='fav_add', channel=channel, show=show_id, title=title,
                                         image=image, poster=poster))]


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[Seriesly %s] %s' % (VERSION, msg), level)


def api_base():
    url = (ADDON.getSetting('api_url') or '').strip().rstrip('/')
    return url or DEFAULT_API


def per_page():
    return int(opt('per_page'))



def api(path, **params):
    """GET στο API του καταλόγου. Επιστρέφει dict ή None (με ειδοποίηση)."""
    params = dict((k, v) for k, v in params.items() if v not in (None, ''))
    url = api_base() + path + ('?' + urlencode(params) if params else '')
    req = Request(url, headers={
        'User-Agent': 'Seriesly-Kodi/' + VERSION,
        'Accept': 'application/json',
    })
    try:
        with urlopen(req, timeout=20) as res:
            return json.loads(res.read().decode('utf-8'))
    except (HTTPError, URLError, ValueError, OSError) as e:
        log('%s -> %s' % (url, e), xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Seriesly', 'Ο κατάλογος δεν απαντά', ICON, 5000)
        return None


def build_url(**query):
    return BASE_URL + '?' + urlencode(dict((k, v) for k, v in query.items() if v not in (None, '')))


def local_date(iso):
    """'2026-09-23T18:20:00+00:00' -> ('23/09/2026', '2026-09-23') σε τοπική ώρα."""
    if not iso:
        return '', ''
    try:
        dt = datetime.fromisoformat(iso).astimezone()
    except ValueError:
        return '', ''
    return dt.strftime('%d/%m/%Y'), dt.strftime('%Y-%m-%d')


def set_info(li, title='', plot='', mediatype='video', aired='', show='', genres=None, studio='', duration=0):
    """InfoTagVideo (Kodi 20+), με εφεδρικό setInfo για παλαιότερα."""
    try:
        tag = li.getVideoInfoTag()
        tag.setMediaType(mediatype)
        if title:
            tag.setTitle(title)
        if plot:
            tag.setPlot(plot)
        if aired:
            tag.setFirstAired(aired)
            tag.setPremiered(aired)
        if show:
            tag.setTvShowTitle(show)
        if genres:
            tag.setGenres(genres)
        if studio:
            tag.setStudios([studio])
        if duration:
            tag.setDuration(int(duration))
    except AttributeError:
        info = {'title': title, 'plot': plot, 'mediatype': mediatype}
        if aired:
            info['aired'] = aired
        if show:
            info['tvshowtitle'] = show
        if genres:
            info['genre'] = genres
        if studio:
            info['studio'] = studio
        if duration:
            info['duration'] = int(duration)
        li.setInfo('video', info)


def art(thumb='', poster='', fanart=''):
    return {
        'icon': thumb or poster or ICON,
        'thumb': thumb or poster or ICON,
        'poster': poster or thumb or ICON,
        'fanart': fanart or FANART,
    }


def add_folder(label, query, thumb='', poster='', plot='', icon='', menu=None):
    li = xbmcgui.ListItem(label)
    if menu:
        li.addContextMenuItems(menu)
    li.setArt(art(thumb, poster))
    if icon:
        li.setArt({'icon': media(icon), 'thumb': media(icon)})
    if plot:
        set_info(li, title=label, plot=plot)
    xbmcplugin.addDirectoryItem(HANDLE, build_url(**query), li, isFolder=True)


def clean_ep(label, show=''):
    """Τίτλος επεισοδίου χωρίς σήμανση Kodi, χωρίς «Εκπομπή · » μπροστά και χωρίς «[ΚΑΝΑΛΙ]» στο τέλος."""
    text = re.sub(r'\[/?(?:COLOR[^\]]*|B|I)\]', '', str(label))
    text = re.sub(r'\s+\[[^\]]+\]\s*$', '', text).strip()
    if show and text.startswith(show + ' · '):
        text = text[len(show) + 3:]
    return text


def add_playable(label, stream, thumb='', poster='', plot='', aired='', show='', genres=None, studio='', duration=0,
                 menu=None):
    li = xbmcgui.ListItem(label)
    if menu:
        li.addContextMenuItems(menu)
    li.setArt(art(thumb, poster))
    li.setProperty('IsPlayable', 'true')
    set_info(li, title=label, plot=plot, mediatype='episode', aired=aired, show=show, genres=genres, studio=studio,
             duration=duration)
    xbmcplugin.addDirectoryItem(HANDLE, build_url(mode='play', url=stream, show=show, ep=clean_ep(label, show), ch=studio),
                                li, isFolder=False)


def add_next_page(data, query):
    page = int(data.get('page', 1))
    pages = int(data.get('pages', 1))
    if page < pages:
        nxt = dict(query)
        nxt['page'] = page + 1
        add_folder('Επόμενη Σελίδα (%d/%d) ›' % (page + 1, pages), nxt, icon='next')


def end(content=None, cache=True):
    key = {'tvshows': 'view_shows', 'episodes': 'view_episodes'}.get(content, 'view_menus')
    view = opt(key)
    if not content and view != 'auto':
        content = 'videos'   # το Estuary δείχνει «Αφίσες»/«Τοίχο» μόνο σε οθόνες με περιεχόμενο βίντεο
    if content:
        xbmcplugin.setContent(HANDLE, content)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=cache)
    if view != 'auto':
        xbmc.executebuiltin('Container.SetViewMode(%s)' % view)


def duration_of(item):
    """Διάρκεια σε δευτερόλεπτα από το API (0 = άγνωστη)."""
    try:
        return max(0, int(item.get('duration') or 0))
    except (TypeError, ValueError):
        return 0


def genre_labels(genres):
    return [g.get('label', '') for g in (genres or []) if g.get('label')]


# ---------------------------------------------------------------- οθόνες

# Τύποι όπως στο Seriesly, με την ίδια σειρά (τα Παιδικά πριν από τα Αθλητικά).
TYPES = (('series', 'Σειρές'), ('show', 'Εκπομπές'), ('kids', 'Παιδικά'), ('sports', 'Αθλητικά'))
TYPE_NAMES = dict(TYPES)
TYPE_ICONS = {'series': 'series', 'show': 'shows', 'kids': 'kids', 'sports': 'sports'}


def kids_on():
    return opt('kids_mode') == 'true'


def root():
    if kids_on():
        kids_root()
        return
    counts = {}
    data = api('/menu')
    if data:
        for item in data.get('types', []):
            counts[item.get('id')] = int(item.get('shows', 0))
    for tid, label in TYPES:
        shown = '%s  (%d)' % (label, counts[tid]) if (tid in counts and opt('show_counts') == 'true') else label
        add_folder(shown, {'mode': 'type', 'type': tid}, icon=TYPE_ICONS[tid])
    add_folder('Αγαπημένα', {'mode': 'favs'}, icon='favourites')
    li = xbmcgui.ListItem('Σημερινό Πρόγραμμα')
    li.setArt({'icon': media('schedule'), 'thumb': media('schedule'), 'fanart': FANART})
    set_info(li, title='Σημερινό Πρόγραμμα', plot='Το τηλεοπτικό πρόγραμμα της ημέρας ανά κανάλι · ▶ = υπάρχει στο Seriesly')
    xbmcplugin.addDirectoryItem(HANDLE, build_url(mode='schedule'), li, isFolder=False)
    add_folder('Συνεχής Ροή', {'mode': 'streams'}, icon='stream',
               plot='«Κανάλια» που παίζουν συνεχόμενα επεισόδια — πατάς ένα και απλώς βλέπεις')
    add_folder('Αναζήτηση', {'mode': 'search'}, icon='search')
    add_folder('Ρυθμίσεις', {'mode': 'settings'}, icon='settings')
    end(cache=False)
    intro_once()


def kids_root():
    """Λειτουργία Παιδιών: μόνο παιδικό περιεχόμενο· η έξοδος θέλει PIN."""
    add_folder('Παιδικά: Προστέθηκαν Πρόσφατα', {'mode': 'latest', 'days': 14, 'type': 'kids', 'sort': 'added'},
               icon='added')
    add_folder('Παιδικά: Τελευταία Εβδομάδα', {'mode': 'latest', 'days': 7, 'type': 'kids'}, icon='week')
    add_folder('Παιδικά: Όλες', {'mode': 'shows', 'type': 'kids'}, icon='kids')
    add_folder('Παιδικά: Α – Ω', {'mode': 'letters', 'type': 'kids'}, icon='letters')
    add_stream_item('kids')
    add_folder('Αναζήτηση', {'mode': 'search', 'type': 'kids'}, icon='search')
    li = xbmcgui.ListItem('Έξοδος Από Λειτουργία Παιδιών')
    li.setArt({'icon': media('exit'), 'thumb': media('exit'), 'fanart': FANART})
    xbmcplugin.addDirectoryItem(HANDLE, build_url(mode='kids_exit'), li, isFolder=False)
    end(cache=False)


def ask_pin(heading):
    try:
        return xbmcgui.Dialog().numeric(0, heading, '', True)
    except TypeError:
        return xbmcgui.Dialog().numeric(0, heading)


def kids_enter():
    """Ενεργοποίηση: ορισμός PIN 4 ψηφίων (δύο φορές, για επιβεβαίωση)."""
    pin = ask_pin('Λειτουργία Παιδιών — Νέο PIN (4 Ψηφία)')
    if not pin or len(pin) != 4 or not pin.isdigit():
        xbmcgui.Dialog().notification('Seriesly', 'Το PIN πρέπει να έχει 4 ψηφία', ICON, 3000)
        return
    if ask_pin('Επιβεβαίωση PIN') != pin:
        xbmcgui.Dialog().notification('Seriesly', 'Τα PIN δεν ταιριάζουν', ICON, 3000)
        return
    ADDON.setSetting('kids_pin', pin)
    ADDON.setSetting('kids_mode', 'true')
    xbmcgui.Dialog().notification('Seriesly', 'Λειτουργία Παιδιών: ενεργή', ICON, 3000)
    xbmc.executebuiltin('Container.Update(%s,replace)' % BASE_URL)


def kids_exit():
    pin = ask_pin('Έξοδος — PIN Λειτουργίας Παιδιών')
    if pin and pin == ADDON.getSetting('kids_pin'):
        ADDON.setSetting('kids_mode', 'false')
        xbmcgui.Dialog().notification('Seriesly', 'Λειτουργία Παιδιών: ανενεργή', ICON, 3000)
        xbmc.executebuiltin('Container.Update(%s,replace)' % BASE_URL)
    elif pin:
        xbmcgui.Dialog().notification('Seriesly', 'Λάθος PIN', ICON, 3000)


# ---------------------------------------------------------------- συνεχής ροή («κανάλια»)

STREAMS = (
    ('series', 'Κανάλι Σειρών'),
    ('show', 'Κανάλι Εκπομπών'),
    ('kids', 'Παιδικό Κανάλι'),
    ('sports', 'Αθλητικό Κανάλι'),
    ('favs', 'Από Τα Αγαπημένα Μου'),
)


def add_stream_item(kind):
    label = dict(STREAMS).get(kind, '')
    li = xbmcgui.ListItem('▶ ' + label)
    li.setArt({'icon': media('stream'), 'thumb': media('stream'), 'fanart': FANART})
    set_info(li, title=label, plot='Τίκαρε τις σειρές που θέλεις και διάλεξε σειρά αναπαραγωγής — φτιάχνεις το δικό σου '
                                    'πρόγραμμα (τα 5 τελευταία επεισόδια κάθε σειράς). Οι επιλογές σου μένουν για την '
                                    'επόμενη φορά. Στο τέλος η αναπαραγωγή σταματά.')
    xbmcplugin.addDirectoryItem(HANDLE, build_url(mode='stream', kind=kind), li, isFolder=False)


def streams():
    for kind, _ in STREAMS:
        add_stream_item(kind)
    end(cache=False)


ORDERS = (('alt', 'Εναλλάξ — 1 Από Κάθε Σειρά, Μετά Ξανά'),
          ('seq', 'Κατά Σειρά — Όλα Της 1ης, Μετά Της 2ης…'),
          ('date', 'Με Ημερομηνία — Παλαιότερο → Νεότερο'))
EPISODES_PER_SHOW = 5


def picks_file():
    folder = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    if not xbmcvfs.exists(folder):
        xbmcvfs.mkdirs(folder)
    return os.path.join(folder, 'streams.json')


def picks_load():
    try:
        with open(picks_file(), 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def picks_save(data):
    try:
        with open(picks_file(), 'w', encoding='utf-8') as fh:
            json.dump(data, fh, ensure_ascii=False)
    except OSError:
        log('δεν αποθηκεύτηκαν οι επιλογές της Συνεχούς Ροής', xbmc.LOGWARNING)


def stream_shows(kind):
    """Οι σειρές/εκπομπές του «καναλιού»: [(channel, id, τίτλος, κανάλι-ετικέτα)] — πιο πρόσφατες πρώτα."""
    if kind == 'favs':
        return [(x.get('channel'), x.get('id'), x.get('title', ''), '') for x in fav_load()]
    data = api('/shows', type=kind, sort='recent', page=1, per_page=100)
    return [(x.get('channel'), x.get('id'), x.get('title', ''), x.get('channel_label', ''))
            for x in (data or {}).get('items', []) if int(x.get('episodes', 0)) > 0]


def stream(kind):
    """Συνεχής Ροή: ο χρήστης τικάρει ΤΙ θα δει και ΜΕ ΠΟΙΑ ΣΕΙΡΑ — τίποτα τυχαίο. Χωρίς script παρασκηνίου."""
    if kids_on() and kind != 'kids':
        return
    shows = stream_shows(kind)
    if not shows:
        xbmcgui.Dialog().notification('Seriesly', 'Δεν βρέθηκαν σειρές για αυτό το κανάλι', ICON, 4000)
        return
    saved = picks_load().get(kind, {})
    keys = ['%s:%s' % (c, i) for c, i, _, _ in shows]
    pre = [n for n, k in enumerate(keys) if k in saved.get('shows', [])]
    labels = [('%s  [%s]' % (t, lab)) if lab else t for _, _, t, lab in shows]
    heading = '%s — Τίκαρε Τι Θέλεις Να Δεις' % dict(STREAMS).get(kind, '')
    try:
        chosen = xbmcgui.Dialog().multiselect(heading, labels, preselect=pre)
    except TypeError:
        chosen = xbmcgui.Dialog().multiselect(heading, labels)
    if chosen is None:
        return
    if not chosen:
        xbmcgui.Dialog().notification('Seriesly', 'Δεν τίκαρες καμία σειρά', ICON, 3000)
        return
    order_ids = [o for o, _ in ORDERS]
    last = order_ids.index(saved.get('order')) if saved.get('order') in order_ids else 0
    try:
        o = xbmcgui.Dialog().select('Σειρά Αναπαραγωγής', [lab for _, lab in ORDERS], preselect=last)
    except TypeError:
        o = xbmcgui.Dialog().select('Σειρά Αναπαραγωγής', [lab for _, lab in ORDERS])
    if o < 0:
        return
    data = picks_load()
    data[kind] = {'shows': [keys[n] for n in chosen], 'order': order_ids[o]}
    picks_save(data)
    per_show = []
    for n in chosen[:25]:
        c, i, t, _ = shows[n]
        res = api('/episodes', show=i, channel=c, page=1, per_page=EPISODES_PER_SHOW)
        eps = [e for e in (res or {}).get('items', []) if e.get('stream')]
        for e in eps:
            e['_show'] = t
        per_show.append(list(reversed(eps)))   # μέσα στη σειρά: παλαιότερο → νεότερο
    items = playlist_order(per_show, order_ids[o])
    if not items:
        xbmcgui.Dialog().notification('Seriesly', 'Δεν βρέθηκαν επεισόδια', ICON, 4000)
        return
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playlist.clear()
    for e in items:
        label = '%s · %s' % (e.get('_show') or e.get('show_title', ''), e.get('title', ''))
        li = xbmcgui.ListItem(label)
        li.setArt(art(e.get('image', ''), e.get('show_poster', '')))
        li.setProperty('IsPlayable', 'true')
        set_info(li, title=label, plot=e.get('description', ''), mediatype='episode', show=e.get('_show', ''),
                 studio=e.get('channel_label', ''), duration=duration_of(e))
        playlist.add(build_url(mode='play', url=e.get('stream', ''), show=e.get('_show', ''), ep=e.get('title', ''),
                               ch=e.get('channel_label', '')), li)
    xbmc.Player().play(playlist)


def playlist_order(per_show, order):
    """alt: εναλλάξ · seq: σειρά-σειρά · date: όλα με ημερομηνία (παλαιότερο → νεότερο)."""
    if order == 'seq':
        return [e for eps in per_show for e in eps]
    if order == 'date':
        return sorted([e for eps in per_show for e in eps], key=lambda e: e.get('published') or '')
    out = []
    for k in range(max([len(eps) for eps in per_show] or [0])):
        for eps in per_show:
            if k < len(eps):
                out.append(eps[k])
    return out


def type_menu(ty):
    """Ένας τύπος (Σειρές / Εκπομπές / Παιδικά / Αθλητικά): μόνο το δικό του περιεχόμενο."""
    name = TYPE_NAMES.get(ty, '')
    add_folder('%s: Προστέθηκαν Πρόσφατα' % name, {'mode': 'latest', 'days': 14, 'type': ty, 'sort': 'added'},
               plot='Επεισόδια που μπήκαν πρόσφατα στον κατάλογο — τα πιο πρόσφατα πρώτα', icon='added')
    add_folder('%s: Σήμερα' % name, {'mode': 'latest', 'day': 'today', 'type': ty}, icon='today')
    add_folder('%s: Χθες' % name, {'mode': 'latest', 'day': 'yesterday', 'type': ty}, icon='yesterday')
    add_folder('%s: Τελευταία Εβδομάδα' % name, {'mode': 'latest', 'days': 7, 'type': ty}, icon='week')
    if ty == 'series':
        year = datetime.now().year
        add_folder('Σειρές %d' % year, {'mode': 'shows', 'type': 'series', 'year': year, 'sort': 'recent'},
                   plot='Σειρές με επεισόδιο μέσα στο %d — πρώτες όσες ανέβασαν πιο πρόσφατα επεισόδιο' % year,
                   icon='year')
    add_folder('%s: Ανά Κανάλι' % name, {'mode': 'channels', 'type': ty}, icon='channels')
    add_folder('%s: Ανά Είδος' % name, {'mode': 'genres', 'type': ty}, icon='genres')
    add_folder('%s: Α – Ω' % name, {'mode': 'letters', 'type': ty}, icon='letters')
    add_folder('%s: Όλες' % name, {'mode': 'shows', 'type': ty}, icon='all')
    end(cache=False)


def channels(ty=''):
    data = api('/menu', type=ty)
    if data:
        for c in data.get('channels', []):
            add_folder('%s  (%d)' % (c.get('label', c.get('id')), int(c.get('shows', 0))),
                       {'mode': 'channel', 'channel': c.get('id'), 'title': c.get('label', ''), 'type': ty},
                       icon='channels')
    end(cache=False)


def channel(ch, title, ty=''):
    if ty:
        # Κανάλι μέσα σε έναν τύπο: πρόσφατα + όλες οι εκπομπές αυτού του τύπου.
        add_folder('%s: Τελευταία Εβδομάδα' % title, {'mode': 'latest', 'days': 7, 'channel': ch, 'type': ty}, icon='week')
        add_folder('%s: Όλες' % title, {'mode': 'shows', 'channel': ch, 'type': ty}, icon='all')
        end(cache=False)
        return
    add_folder('%s: Τελευταία Εβδομάδα' % title, {'mode': 'latest', 'days': 7, 'channel': ch}, icon='week')
    add_folder('%s: Όλες Οι Εκπομπές' % title, {'mode': 'shows', 'channel': ch}, icon='all')
    data = api('/menu')
    if data:
        for g in data.get('genres', []):
            add_folder('%s: %s' % (title, g.get('label', '')), {'mode': 'shows', 'channel': ch, 'genre': g.get('id')},
                       icon='genres')
    end(cache=False)


def genres(ty=''):
    data = api('/menu', type=ty)
    if data:
        for g in data.get('genres', []):
            if int(g.get('shows', 0)) <= 0:
                continue
            add_folder('%s  (%d)' % (g.get('label', ''), int(g.get('shows', 0))),
                       {'mode': 'shows', 'genre': g.get('id'), 'type': ty}, icon='genres')
    end(cache=False)


def letters(ty=''):
    data = api('/menu', type=ty)
    if data:
        for item in data.get('letters', []):
            letter = item.get('letter', '')
            add_folder('%s  (%d)' % (letter, int(item.get('shows', 0))), {'mode': 'shows', 'letter': letter, 'type': ty})
    end(cache=False)


def shows(query):
    page = int(query.get('page', 1))
    sort = query.get('sort') or ('recent' if opt('show_sort') == 'recent' else None)
    data = api('/shows', channel=query.get('channel'), genre=query.get('genre'),
               letter=query.get('letter'), q=query.get('q'), type=query.get('type'),
               year=query.get('year'), sort=sort, page=page, per_page=per_page())
    if data:
        many_channels = not query.get('channel')
        favs = fav_keys()
        for s in data.get('items', []):
            label = s.get('title', '')
            if fav_key(s.get('channel'), s.get('id')) in favs:
                label = '★ ' + label
            if many_channels:
                label += channel_tag(s)
            count = int(s.get('episodes', 0))
            if count > 0:
                last, _ = local_date(s.get('last'))
                plot = '%d %s%s' % (count, 'επεισόδιο' if count == 1 else 'επεισόδια',
                                    (' · τελευταίο %s' % last) if last else '')
                add_folder(label, {'mode': 'episodes', 'show': s.get('id'), 'channel': s.get('channel'),
                                   'title': s.get('title', '')},
                           thumb=s.get('image', ''), poster=s.get('poster', ''), plot=plot,
                           menu=fav_menu(s.get('channel'), s.get('id'), s.get('title', ''),
                                         s.get('image', ''), s.get('poster', '')))
            elif s.get('stream'):
                add_playable(label, s['stream'], thumb=s.get('image', ''), poster=s.get('poster', ''),
                             show=s.get('title', ''), genres=genre_labels(s.get('genres')),
                             studio=s.get('channel_label', ''))
        base = dict((k, v) for k, v in query.items() if k in ('mode', 'channel', 'genre', 'letter', 'q', 'type', 'year', 'sort'))
        base['mode'] = 'shows'
        add_next_page(data, base)
    end('tvshows')


def episodes(query):
    page = int(query.get('page', 1))
    data = api('/episodes', show=query.get('show'), channel=query.get('channel'), page=page, per_page=per_page())
    if data:
        for e in data.get('items', []):
            shown, aired = local_date(e.get('published'))
            title = e.get('title', '')
            label = title if (not shown or shown in title) else '%s  (%s)' % (title, shown)
            add_playable(label, e.get('stream', ''), thumb=e.get('image', ''), poster=e.get('show_poster', ''),
                         plot=e.get('description', ''), aired=aired, show=e.get('show_title', ''),
                         genres=genre_labels(e.get('genres')), studio=e.get('channel_label', ''),
                         duration=duration_of(e),
                         menu=fav_menu(query.get('channel'), query.get('show'), query.get('title', ''),
                                       poster=e.get('show_poster', '')))
        add_next_page(data, {'mode': 'episodes', 'show': query.get('show'), 'channel': query.get('channel'),
                             'title': query.get('title', '')})
    end('episodes')


def latest(query):
    page = int(query.get('page', 1))
    data = api('/latest', day=query.get('day'), days=query.get('days'), channel=query.get('channel'),
               genre=query.get('genre'), type=query.get('type'), sort=query.get('sort'), page=page, per_page=per_page())
    if data:
        for e in data.get('items', []):
            shown, aired = local_date(e.get('published'))
            show = e.get('show_title', '')
            label = '%s · %s' % (show, e.get('title', '')) if show else e.get('title', '')
            if not query.get('channel'):
                label += channel_tag(e)
            add_playable(label, e.get('stream', ''), thumb=e.get('image', ''), poster=e.get('show_poster', ''),
                         plot=e.get('description', ''), aired=aired, show=show,
                         genres=genre_labels(e.get('genres')), studio=e.get('channel_label', ''),
                         duration=duration_of(e),
                         menu=fav_menu(e.get('channel'), e.get('show_id'), show, poster=e.get('show_poster', '')))
        if not data.get('items'):
            xbmcgui.Dialog().notification('Seriesly', 'Δεν υπάρχουν επεισόδια για αυτό το διάστημα', ICON, 4000)
        base = dict((k, v) for k, v in query.items() if k in ('mode', 'day', 'days', 'channel', 'genre', 'type', 'sort'))
        add_next_page(data, base)
    end('episodes', cache=False)


def search(ty=''):
    kb = xbmc.Keyboard('', 'Αναζήτηση Σειράς Ή Εκπομπής')
    kb.doModal()
    if not kb.isConfirmed():
        end(cache=False)
        return
    text = kb.getText().strip()
    if not text:
        end(cache=False)
        return
    shows({'mode': 'shows', 'q': text, 'type': ty} if ty else {'mode': 'shows', 'q': text})


ABOUT_TITLE = 'Καλώς Ήρθες Στο Seriesly'
ABOUT_TEXT = (
    '[B]Τι είναι το Seriesly[/B]\n'
    'Το Seriesly οργανώνει σε έναν ενιαίο, εύχρηστο κατάλογο τις σειρές, τις εκπομπές, τα παιδικά και τα αθλητικά '
    'προγράμματα που τα ίδια τα ελληνικά τηλεοπτικά κανάλια διαθέτουν δημόσια και δωρεάν στους επίσημους '
    'ιστότοπούς τους.\n\n'
    '[B]Από πού προέρχεται το περιεχόμενο[/B]\n'
    'Αποκλειστικά από τις επίσημες σελίδες των καναλιών: MEGA, ANT1, Alpha, ΣΚΑΪ, STAR και OPEN. Ο κατάλογος '
    'διαβάζει τα δημόσια ευρετήρια (sitemaps) και τις σελίδες σειρών τους, όπως κάνει κάθε μηχανή αναζήτησης, '
    'σεβόμενος τους κανόνες (robots.txt) κάθε ιστότοπου.\n\n'
    '[B]Πώς παίζουν τα βίντεο[/B]\n'
    'Κάθε επεισόδιο παίζει απευθείας από τους servers του καναλιού στο οποίο ανήκει — ακριβώς όπως στον δικό του '
    'ιστότοπο. Το Seriesly δεν φιλοξενεί, δεν αποθηκεύει, δεν αντιγράφει και δεν αναμεταδίδει κανένα βίντεο.\n\n'
    '[B]Τι δεν περιλαμβάνεται[/B]\n'
    '• Περιεχόμενο με τεχνική προστασία αντιγραφής (DRM) ή από συνδρομητικές υπηρεσίες\n'
    '• Ζωντανές μεταδόσεις\n'
    '• Δελτία ειδήσεων\n'
    'Όπου ένα κανάλι διαθέτει ένα επεισόδιο μόνο στην Ελλάδα, το βίντεο το ζητά η δική σου συσκευή, όπως στον '
    'ιστότοπο του καναλιού — κανένας περιορισμός δεν παρακάμπτεται.\n\n'
    '[B]Διαθεσιμότητα[/B]\n'
    'Τα νέα επεισόδια εμφανίζονται συνήθως μέσα σε περίπου μία ώρα αφότου τα ανεβάσει το κανάλι. Η διαθεσιμότητα '
    'κάθε επεισοδίου εξαρτάται αποκλειστικά από το κανάλι που το διαθέτει.\n\n'
    '[B]Πνευματικά δικαιώματα[/B]\n'
    'Όλα τα δικαιώματα ανήκουν στους νόμιμους δικαιούχους — τα κανάλια και τους παραγωγούς. Ονόματα, λογότυπα και '
    'εικόνες εμφανίζονται μόνο για την αναγνώριση του περιεχομένου.\n\n'
    '[B]Στατιστικά χρήσης[/B]\n'
    'Για να βλέπει ο διαχειριστής πόσοι χρησιμοποιούν το Seriesly, στέλνεται ανώνυμα ένα αναγνωριστικό της συσκευής, '
    'ο τύπος της και τι βλέπεις εκείνη τη στιγμή — χωρίς όνομα, email ή τοποθεσία. Μπορείς να το κλείσεις από '
    'Ρυθμίσεις → Λειτουργία → «Αποστολή Στατιστικών Χρήσης».\n\n'
    '[B]Χρήση[/B]\n'
    'Προσωπική, μη εμπορική, χωρίς καμία χρέωση.\n\n'
    '[I]Μπορείς να ξαναδείς αυτό το κείμενο από τις Ρυθμίσεις του πρόσθετου. '
    'Πάτα «Πίσω» ή «OK» για να συνεχίσεις.[/I]'
)


def favourites():
    """★ Αγαπημένα: «Νέα Επεισόδια» και οι αγαπημένες σειρές/εκπομπές."""
    items = fav_load()
    if not items:
        add_folder('Δεν Έχεις Αγαπημένα Ακόμα — Πώς Προσθέτω;', {'mode': 'fav_help'}, icon='info')
        end(cache=False)
        return
    add_folder('Νέα Επεισόδια', {'mode': 'fav_new'}, icon='added',
               plot='Τα πιο πρόσφατα επεισόδια από τα αγαπημένα σου')
    for x in sorted(items, key=lambda i: i.get('title', '')):
        add_folder(x.get('title', ''), {'mode': 'episodes', 'show': x.get('id'), 'channel': x.get('channel'),
                                        'title': x.get('title', '')},
                   thumb=x.get('image', ''), poster=x.get('poster', ''),
                   menu=fav_menu(x.get('channel'), x.get('id'), x.get('title', '')))
    end('tvshows', cache=False)


def fav_new():
    """Νέα επεισόδια από τα αγαπημένα (τα 5 νεότερα κάθε σειράς, όλα μαζί με ημερομηνία)."""
    found = []
    for x in fav_load()[:30]:
        data = api('/episodes', show=x.get('id'), channel=x.get('channel'), page=1, per_page=5)
        for e in (data or {}).get('items', []):
            e['_show'] = x.get('title', '')
            found.append(e)
    found.sort(key=lambda e: e.get('published') or '', reverse=True)
    for e in found[:60]:
        shown, aired = local_date(e.get('published'))
        label = '%s · %s' % (e['_show'], e.get('title', '')) + channel_tag(e)
        add_playable(label, e.get('stream', ''), thumb=e.get('image', ''), poster=e.get('show_poster', ''),
                     plot=e.get('description', ''), aired=aired, show=e['_show'],
                     genres=genre_labels(e.get('genres')), studio=e.get('channel_label', ''), duration=duration_of(e))
    if not found:
        xbmcgui.Dialog().notification('Seriesly', 'Δεν βρέθηκαν επεισόδια', ICON, 4000)
    end('episodes', cache=False)


def fav_add(query):
    items = fav_load()
    key = fav_key(query.get('channel'), query.get('show'))
    if key not in fav_keys() and query.get('show'):
        items.append({'id': query.get('show'), 'channel': query.get('channel'), 'title': query.get('title', ''),
                      'image': query.get('image', ''), 'poster': query.get('poster', '')})
        fav_save(items)
    xbmcgui.Dialog().notification('Seriesly', '★ Προστέθηκε Στα Αγαπημένα', ICON, 2500)
    xbmc.executebuiltin('Container.Refresh')


def fav_del(query):
    key = fav_key(query.get('channel'), query.get('show'))
    fav_save([x for x in fav_load() if fav_key(x.get('channel'), x.get('id')) != key])
    xbmcgui.Dialog().notification('Seriesly', 'Αφαιρέθηκε Από Τα Αγαπημένα', ICON, 2500)
    xbmc.executebuiltin('Container.Refresh')


def fav_help():
    xbmcgui.Dialog().ok('Αγαπημένα', 'Πάτα [B]παρατεταμένα[/B] το OK του τηλεχειριστηρίου (ή δεξί κλικ) πάνω σε μια '
                                     'σειρά ή ένα επεισόδιο και διάλεξε [B]«☆ Προσθήκη Στα Αγαπημένα»[/B].\n'
                                     'Θα τη βρίσκεις εδώ, μαζί με τα νέα της επεισόδια.')


def schedule():
    """Σημερινό Πρόγραμμα: παράθυρο καναλιών → παράθυρο προγράμματος (Πίσω = ένα βήμα πίσω, χωρίς να φύγεις)."""
    data = api('/schedule')
    chans = (data or {}).get('channels', [])
    if not chans:
        xbmcgui.Dialog().notification('Seriesly', 'Το πρόγραμμα δεν είναι διαθέσιμο αυτή τη στιγμή', ICON, 4000)
        return
    while True:
        pick = xbmcgui.Dialog().select('Σημερινό Πρόγραμμα — Διάλεξε Κανάλι', [c.get('label', '') for c in chans])
        if pick < 0:
            return
        if schedule_channel(chans[pick]):
            return


def schedule_channel(chan):
    """Το πρόγραμμα ενός καναλιού. True = ο χρήστης άνοιξε εκπομπή (τέλος)· False = Πίσω στα κανάλια."""
    data = api('/schedule', channel=chan.get('id'))
    items = (data or {}).get('items', [])
    if not items:
        xbmcgui.Dialog().notification('Seriesly', 'Δεν βρέθηκε πρόγραμμα για %s' % chan.get('label', ''), ICON, 4000)
        return False
    lines, now = [], 0
    for i, it in enumerate(items):
        time_ = ('~' if it.get('approx') else '') + (it.get('time') or '—:—')
        mark = '▶ ' if it.get('show_id') else '    '
        line = '%s   %s%s' % (time_, mark, it.get('title', ''))
        if it.get('now'):
            now = i
            line = '[B]%s   · ΤΩΡΑ[/B]' % line
        lines.append(line)
    day = (data or {}).get('date', '')
    heading = '%s — Πρόγραμμα %s' % (chan.get('label', ''), '/'.join(reversed(day.split('-')[1:])) if day else '')
    while True:
        try:
            pick = xbmcgui.Dialog().select(heading, lines, preselect=now)
        except TypeError:
            pick = xbmcgui.Dialog().select(heading, lines)
        if pick < 0:
            return False
        it = items[pick]
        if it.get('show_id'):
            xbmc.executebuiltin('Container.Update(%s)' % build_url(mode='episodes', show=it.get('show_id'),
                                                                     channel=chan.get('id'),
                                                                     title=it.get('show_title') or it.get('title', '')))
            return True
        xbmcgui.Dialog().notification('Seriesly', 'Αυτό το πρόγραμμα δεν υπάρχει (ακόμα) στο Seriesly', ICON, 3000)
        now = pick


def settings_menu():
    add_folder('Εμφάνιση', {'mode': 'settings_group', 'group': 'appearance'}, icon='appearance',
               plot='Πώς φαίνεται το πρόσθετο')
    add_folder('Λειτουργία', {'mode': 'settings_group', 'group': 'functions'}, icon='functions',
               plot='Πώς δουλεύει το πρόσθετο')
    end(cache=False)


def settings_group(group):
    """Κάθε ρύθμιση μία γραμμή: «Τίτλος: Τιμή» — ένα πάτημα την αλλάζει."""
    keys = APPEARANCE if group == 'appearance' else FUNCTIONS
    icon = 'appearance' if group == 'appearance' else 'functions'
    for key in keys:
        li = xbmcgui.ListItem('%s: [B]%s[/B]' % (OPTIONS[key][0], opt_label(key)))
        own = KEY_ICONS.get(key[:5], KEY_ICONS.get(key, icon))
        li.setArt({'icon': media(own), 'thumb': media(own), 'fanart': FANART})
        xbmcplugin.addDirectoryItem(HANDLE, build_url(mode='toggle', key=key), li, isFolder=False)
    if group == 'functions':
        add_folder('Πληροφορίες & Κατάσταση', {'mode': 'status'}, icon='info')
        add_folder('Τι Είναι Το Seriesly', {'mode': 'about'}, icon='info')
    end(cache=False)


def toggle(key):
    """Επόμενη τιμή της ρύθμισης (κυκλικά) και ανανέωση της οθόνης."""
    if key not in OPTIONS:
        return
    if key == 'kids_mode':
        kids_enter()
        return
    values = [v for v, _ in OPTIONS[key][1]]
    ADDON.setSetting(key, values[(values.index(opt(key)) + 1) % len(values)])
    xbmc.executebuiltin('Container.Refresh')


def status():
    """Πληροφορίες & Κατάσταση: έκδοση, αν απαντά ο κατάλογος, πλήθη, τελευταίο επεισόδιο."""
    lines = ['[B]Seriesly[/B] %s' % VERSION]
    data = api('/menu')
    if data:
        lines.append('Κατάλογος: [COLOR FF27AE60]απαντά κανονικά[/COLOR]')
        for tid, label in TYPES:
            n = next((int(t.get('shows', 0)) for t in data.get('types', []) if t.get('id') == tid), 0)
            lines.append('%s: %d' % (label, n))
        chans = ', '.join(c.get('label', '') for c in data.get('channels', []))
        if chans:
            lines.append('Κανάλια: %s' % chans)
        last = api('/latest', days=2, sort='added', page=1, per_page=1)
        items = (last or {}).get('items', [])
        if items:
            when, _ = local_date(items[0].get('added') or items[0].get('published'))
            lines.append('Τελευταίο επεισόδιο: %s · %s (%s)' % (items[0].get('show_title', ''),
                                                            items[0].get('title', ''), when))
    else:
        lines.append('Κατάλογος: [COLOR FFEB5757]δεν απαντά[/COLOR] — δοκίμασε ξανά σε λίγο')
    lines.append('Αγαπημένα: %d' % len(fav_load()))
    xbmcgui.Dialog().textviewer('Πληροφορίες & Κατάσταση', '\n'.join(lines))


def about():
    xbmcgui.Dialog().textviewer(ABOUT_TITLE, ABOUT_TEXT)


INTRO_REV = '2'   # αλλάζει όταν αλλάζει το κείμενο: το παράθυρο εμφανίζεται ξανά μία φορά (1.3.0: στατιστικά χρήσης)


def intro_once():
    """Την πρώτη φορά που ανοίγει το πρόσθετο — και μία φορά ξανά όταν αλλάζει το κείμενο: πλήρης εξήγηση."""
    if ADDON.getSetting('intro_rev') == INTRO_REV:
        return
    ADDON.setSetting('intro_rev', INTRO_REV)
    about()


ANT1_PLAYER = 'https://www.antenna.gr/templates/data/PlayerDataGraphQL_v2?cid='


def resolve_ant1(code):
    """ANT1 με περιορισμό χώρας: ρωτά τον player του ANT1 ΑΠΟ ΑΥΤΗ ΤΗ ΣΥΣΚΕΥΗ (Ελλάδα), όπως το antenna.gr.
    Επιστρέφει τη διεύθυνση του βίντεο ή '' («NO GR» / σφάλμα)."""
    try:
        req = Request(ANT1_PLAYER + code, headers={'User-Agent': 'Mozilla/5.0 (Kodi) Seriesly'})
        with urlopen(req, timeout=15) as res:
            data = json.loads(res.read().decode('utf-8'))
    except (URLError, HTTPError, ValueError, OSError):
        return ''
    video = data.get('url', '') if isinstance(data, dict) else ''
    if not isinstance(video, str):
        return ''
    if video.startswith('//'):
        video = 'https:' + video
    low = video.lower().split('?')[0]
    if not video.startswith('https://') or 'nogr' in low or not low.endswith(('.mp4', '.m3u8')):
        return ''
    return video


def remember_playing(url, query):
    """Για την υπηρεσία παρασκηνίου: τι μόλις ξεκίνησε να παίζει (σειρά, τίτλος, κανάλι)."""
    q = query or {}
    try:
        xbmcgui.Window(10000).setProperty('seriesly.now', json.dumps({
            'url': url, 'show': q.get('show', ''), 'title': q.get('ep', ''), 'channel': q.get('ch', ''), 'ts': time.time()}))
    except Exception:
        pass


def play(url, query=None):
    if url.startswith('ant1:'):
        url = resolve_ant1(url[5:])
        if not url:
            xbmcgui.Dialog().notification('Seriesly', 'Ο ANT1 δεν διαθέτει αυτό το επεισόδιο online αυτή τη στιγμή.',
                                          xbmcgui.NOTIFICATION_INFO, 5000)
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            return
    li = xbmcgui.ListItem(path=url)
    low = url.lower().split('?')[0]
    if low.endswith('.m3u8'):
        li.setMimeType('application/vnd.apple.mpegurl')
        li.setContentLookup(False)
    elif low.endswith('.mp4'):
        li.setMimeType('video/mp4')
        li.setContentLookup(False)
    remember_playing(url, query)
    xbmcplugin.setResolvedUrl(HANDLE, bool(url), li)


# ---------------------------------------------------------------- δρομολόγηση

KIDS_MODES = (None, 'type', 'channels', 'channel', 'genres', 'letters', 'shows', 'episodes', 'latest', 'search',
              'play', 'stream', 'kids_exit', 'about')


def router(query):
    mode = query.get('mode')
    if kids_on():
        if mode not in KIDS_MODES:
            xbmcgui.Dialog().notification('Seriesly', 'Κλειδωμένο στη Λειτουργία Παιδιών', ICON, 3000)
            mode = None
        elif mode not in (None, 'episodes', 'play', 'stream', 'kids_exit', 'about', 'channel'):
            query['type'] = 'kids'   # όλες οι λίστες: μόνο παιδικά
        elif mode == 'channel':
            query['type'] = 'kids'
    if mode is None:
        root()
    elif mode == 'type':
        type_menu(query.get('type', ''))
    elif mode == 'channels':
        channels(query.get('type', ''))
    elif mode == 'channel':
        channel(query.get('channel', ''), query.get('title', ''), query.get('type', ''))
    elif mode == 'genres':
        genres(query.get('type', ''))
    elif mode == 'letters':
        letters(query.get('type', ''))
    elif mode == 'about':
        about()
    elif mode == 'favs':
        favourites()
    elif mode == 'fav_new':
        fav_new()
    elif mode == 'fav_add':
        fav_add(query)
    elif mode == 'fav_del':
        fav_del(query)
    elif mode == 'fav_help':
        fav_help()
    elif mode == 'settings':
        settings_menu()
    elif mode == 'settings_group':
        settings_group(query.get('group', ''))
    elif mode == 'toggle':
        toggle(query.get('key', ''))
    elif mode == 'status':
        status()
    elif mode == 'streams':
        streams()
    elif mode == 'schedule':
        schedule()
    elif mode == 'stream':
        stream(query.get('kind', ''))
    elif mode == 'kids_exit':
        kids_exit()
    elif mode == 'shows':
        shows(query)
    elif mode == 'episodes':
        episodes(query)
    elif mode == 'latest':
        latest(query)
    elif mode == 'search':
        search(query.get('type', ''))
    elif mode == 'play':
        play(query.get('url', ''), query)
    else:
        log('άγνωστο mode: %s' % mode, xbmc.LOGWARNING)
        root()


if __name__ == '__main__':
    router(ARGS)
