# -*- coding: utf-8 -*-
"""
Seriesly - υπηρεσία παρασκηνίου του Kodi (ξεκινά μόνη της με το Kodi, μέσα στο ίδιο πρόσθετο).

Στέλνει στο Seriesly (WordPress, πάνελ «Τώρα βλέπουν») ανώνυμα σήματα «είμαι μέσα» / «βλέπω αυτό»:
  - αναγνωριστικό συσκευής (τυχαίο, φτιάχνεται την πρώτη φορά), όνομα συσκευής του Kodi, έκδοση Kodi/πρόσθετου
  - όταν παίζει από το Seriesly: σειρά, επεισόδιο, κανάλι, θέση, διάρκεια, και αν είναι σε παύση
Χρόνος: κάθε 30 δευτερόλεπτα όταν παίζει, κάθε 60 όταν ο χρήστης είναι στις λίστες, και αμέσως σε κάθε αλλαγή.
Δεν στέλνεται τίποτα όταν ο χρήστης είναι αλλού στο Kodi, ούτε όταν είναι κλειστή η «Αποστολή Στατιστικών Χρήσης».
Κανένα όνομα, email ή τοποθεσία.
"""
import hashlib
import json
import time
import uuid
from urllib.parse import urlparse
from urllib.request import Request, urlopen

import xbmc
import xbmcaddon
import xbmcgui

ADDON_ID = 'plugin.video.seriesly'
PROP = 'seriesly.now'
SERIES_PATH = '/wp-json/dp82s/v1/'     # διεύθυνση του Seriesly (WordPress) — μία γραμμή, ώστε να αλλάζει εύκολα
BEAT_PLAY = 30                          # δευτερόλεπτα ανά σήμα όταν παίζει
BEAT_IDLE = 60                          # δευτερόλεπτα ανά σήμα στις λίστες
POLL = 5                                # κάθε πόσο κοιτάζει το Kodi
GRACE = 20                              # τόσα δευτερόλεπτα μετά το play θεωρείται «δικό μας» ό,τι παίζει


class Tracker(object):
    """Αποφασίζει ΠΟΤΕ να σταλεί σήμα. Καθαρή λογική, χωρίς Kodi — δοκιμάζεται με σενάρια."""

    def __init__(self):
        self.state = None     # None | 'browsing' | 'playing' | 'paused'
        self.key = ''
        self.item = None
        self.beat_at = 0.0

    def tick(self, now, state, item):
        """Επιστρέφει λίστα σημάτων [(state, item|None)] που πρέπει να σταλούν τώρα."""
        out = []
        playing = state in ('playing', 'paused')
        key = item['url'] if (playing and item) else ''
        # 1. Έφυγε ή άλλαξε το επεισόδιο ενώ έπαιζε: τελευταίο σήμα, για να μετρήσουν τα τελευταία δευτερόλεπτα.
        if self.state == 'playing' and self.item is not None and (not playing or key != self.key):
            out.append(('playing', self.item))
        # 2. Τώρα.
        if playing:
            if state != self.state or key != self.key or now - self.beat_at >= BEAT_PLAY:
                out.append((state, item))
                self.beat_at = now
        elif state == 'browsing':
            if self.state != 'browsing' or now - self.beat_at >= BEAT_IDLE:
                out.append(('browsing', None))
                self.beat_at = now
        elif self.state is not None:
            out.append(('', None))      # έφυγε από το Seriesly: καθαρίζει το «βλέπει τώρα» στο πάνελ
            self.beat_at = now
        # 3. Μνήμη.
        self.state = state
        self.key = key
        self.item = dict(item) if (playing and item) else None
        return out


def snapshot(k, now, sticky):
    """(state, item, sticky) από το Kodi μέσω του προσαρμογέα k.
    state: None | 'browsing' | 'playing' | 'paused' · sticky: ο χρόνος του play που αναγνωρίστηκε ως «δικό μας»."""
    try:
        if k.playing_video():
            prop = k.prop()
            if not prop:
                return None, None, None
            ts = float(prop.get('ts', 0))
            ours = (prop.get('url') == k.playing_file()) or (now - ts < GRACE) or (sticky is not None and ts == sticky)
            if not ours:
                return None, None, None     # παίζει κάτι άλλο (άλλο πρόσθετο): δεν μετράμε
            item = {
                'url': prop.get('url') or k.playing_file(),
                'show': prop.get('show', ''),
                'title': prop.get('title', ''),
                'channel': prop.get('channel', ''),
                'pos': int(k.position()),
                'dur': int(k.total()),
            }
            return ('paused' if k.paused() else 'playing'), item, ts
        if str(k.folder() or '').startswith('plugin://' + ADDON_ID + '/'):
            return 'browsing', None, None
    except Exception:
        pass
    return None, None, None


def build_payload(device, version, detail, friendly, state, item):
    """Το σώμα του /beat — ίδια γλώσσα με την εφαρμογή, με πηγή «kodi»."""
    payload = {'device': device, 'client': 'kodi', 'version': version, 'detail': detail,
               'friendly': friendly, 'state': state}
    if item:
        payload['playing'] = {
            'item': hashlib.md5(item['url'].encode('utf-8')).hexdigest(),
            'channel': item.get('channel', ''),
            'show': item.get('show', ''),
            'title': item.get('title', ''),
            'pos': int(item.get('pos', 0)),
            'dur': int(item.get('dur', 0)),
        }
    return payload


def step(now, k, tracker, sticky, send):
    """Ένας κύκλος: κοιτά το Kodi, αποφασίζει, στέλνει. Επιστρέφει το νέο sticky."""
    state, item, sticky = snapshot(k, now, sticky)
    for st, it in tracker.tick(now, state, item):
        send(st, it)
    return sticky


class KodiAdapter(object):
    """Ό,τι χρειάζεται από το Kodi — ώστε η λογική παραπάνω να δοκιμάζεται χωρίς Kodi."""

    def __init__(self, player):
        self.player = player

    def playing_video(self):
        return self.player.isPlayingVideo()

    def playing_file(self):
        return self.player.getPlayingFile()

    def position(self):
        return self.player.getTime()

    def total(self):
        return self.player.getTotalTime()

    def paused(self):
        return bool(xbmc.getCondVisibility('Player.Paused'))

    def folder(self):
        return xbmc.getInfoLabel('Container.FolderPath')

    def prop(self):
        raw = xbmcgui.Window(10000).getProperty(PROP)
        try:
            data = json.loads(raw) if raw else None
        except ValueError:
            data = None
        return data if isinstance(data, dict) else None


def device_id(addon):
    dev = addon.getSetting('device_id')
    if len(dev) != 32:
        dev = uuid.uuid4().hex
        addon.setSetting('device_id', dev)
    return dev


def series_api(addon):
    """Η διεύθυνση του Seriesly: ίδιο site με τον κατάλογο (ρύθμιση api_url), άλλη διαδρομή."""
    parts = urlparse(addon.getSetting('api_url') or 'https://e-menucms.gr/')
    return '%s://%s%s' % (parts.scheme or 'https', parts.netloc or 'e-menucms.gr', SERIES_PATH)


def post(url, payload, version):
    req = Request(url + 'beat', data=json.dumps(payload).encode('utf-8'),
                  headers={'Content-Type': 'application/json', 'User-Agent': 'Seriesly-Kodi/' + version})
    with urlopen(req, timeout=6) as res:
        res.read()


def run():
    monitor = xbmc.Monitor()
    kodi = KodiAdapter(xbmc.Player())
    tracker = Tracker()
    sticky = None
    while not monitor.abortRequested():
        if monitor.waitForAbort(POLL):
            break
        try:
            addon = xbmcaddon.Addon()          # ξανά κάθε φορά: ισχύει αμέσως ό,τι αλλάζει ο χρήστης στις ρυθμίσεις
            if addon.getSetting('stats_on') == 'false':
                tracker = Tracker()
                sticky = None
                continue
            version = addon.getAddonInfo('version')
            dev = device_id(addon)
            base = series_api(addon)
            build = xbmc.getInfoLabel('System.BuildVersion').split(' ')[0]
            detail = ('Kodi %s · %s' % (build, xbmc.getInfoLabel('System.OSVersionInfo'))).strip(' ·')
            friendly = xbmc.getInfoLabel('System.FriendlyName')

            def send(st, it):
                try:
                    post(base, build_payload(dev, version, detail[:120], friendly[:120], st, it), version)
                except Exception as exc:       # χωρίς δίκτυο/server: σιωπηλά, ξανά στον επόμενο κύκλο
                    xbmc.log('[Seriesly] σήμα χρήσης: %s' % exc, xbmc.LOGDEBUG)

            sticky = step(time.time(), kodi, tracker, sticky, send)
        except Exception as exc:
            xbmc.log('[Seriesly] υπηρεσία: %s' % exc, xbmc.LOGWARNING)


if __name__ == '__main__':
    run()
